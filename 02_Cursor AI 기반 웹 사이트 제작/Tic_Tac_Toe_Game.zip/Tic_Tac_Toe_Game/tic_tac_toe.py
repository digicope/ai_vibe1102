"""Tkinter GUI Tic Tac Toe (사용자 X vs 컴퓨터 O)."""

import math
import tkinter as tk
from tkinter import font as tkfont, messagebox, ttk
from typing import Optional


class TicTacToe:
    """보드 상태와 승패 판정, 컴퓨터 전략을 담당한다."""

    MIN_SIZE = 3
    MAX_SIZE = 10
    HUMAN = "X"
    COMPUTER = "O"
    EMPTY = " "

    def __init__(self, size: int = 3) -> None:
        self.set_size(size)

    def set_size(self, size: int) -> None:
        if not self.MIN_SIZE <= size <= self.MAX_SIZE:
            raise ValueError(f"보드 크기는 {self.MIN_SIZE}~{self.MAX_SIZE}만 가능합니다.")
        self.board_size = size
        self.reset()

    def _create_board(self) -> list[list[str]]:
        return [
            [self.EMPTY for _ in range(self.board_size)]
            for _ in range(self.board_size)
        ]

    def reset(self) -> None:
        self.board = self._create_board()

    def is_occupied(self, row: int, col: int) -> bool:
        return self.board[row][col] != self.EMPTY

    def empty_cells(self) -> list[tuple[int, int]]:
        return [
            (row, col)
            for row in range(self.board_size)
            for col in range(self.board_size)
            if self.board[row][col] == self.EMPTY
        ]

    def place_mark(self, row: int, col: int, mark: str) -> bool:
        if self.is_occupied(row, col):
            return False
        self.board[row][col] = mark
        return True

    def _lines(self) -> list[list[str]]:
        lines = []
        lines.extend(self.board)
        lines.extend(
            [
                [self.board[row][col] for row in range(self.board_size)]
                for col in range(self.board_size)
            ]
        )
        lines.append([self.board[i][i] for i in range(self.board_size)])
        lines.append(
            [self.board[i][self.board_size - 1 - i] for i in range(self.board_size)]
        )
        return lines

    def winning_mark(self) -> Optional[str]:
        for line in self._lines():
            if line[0] != self.EMPTY and all(cell == line[0] for cell in line):
                return line[0]
        return None

    def is_full(self) -> bool:
        return all(cell != self.EMPTY for row in self.board for cell in row)

    def get_result(self) -> Optional[str]:
        winner = self.winning_mark()
        if winner is not None:
            return winner
        if self.is_full():
            return "draw"
        return None

    def _evaluate_terminal(self, depth: int) -> Optional[int]:
        result = self.get_result()
        if result == self.COMPUTER:
            return 10_000 - depth
        if result == self.HUMAN:
            return depth - 10_000
        if result == "draw":
            return 0
        return None

    def _line_score(self, line: list[str]) -> int:
        computer = line.count(self.COMPUTER)
        human = line.count(self.HUMAN)
        if computer and human:
            return 0
        if computer:
            return 10 ** computer
        if human:
            return -(10 ** human)
        return 0

    def _heuristic(self) -> int:
        score = sum(self._line_score(line) for line in self._lines())
        center = self.board_size // 2
        if self.board[center][center] == self.COMPUTER:
            score += 3
        elif self.board[center][center] == self.HUMAN:
            score -= 3
        return score

    def _search_depth(self) -> int:
        if self.board_size <= 3:
            return self.board_size * self.board_size
        if self.board_size <= 4:
            return 3
        if self.board_size <= 6:
            return 2
        return 1

    def _candidate_moves(self) -> list[tuple[int, int]]:
        empties = self.empty_cells()
        if self.board_size <= 3 or len(empties) <= 16:
            return empties

        occupied = [
            (row, col)
            for row in range(self.board_size)
            for col in range(self.board_size)
            if self.board[row][col] != self.EMPTY
        ]
        if not occupied:
            center = self.board_size // 2
            return [(center, center)]

        nearby: set[tuple[int, int]] = set()
        for row, col in occupied:
            for dr in (-1, 0, 1):
                for dc in (-1, 0, 1):
                    nr, nc = row + dr, col + dc
                    if (
                        0 <= nr < self.board_size
                        and 0 <= nc < self.board_size
                        and self.board[nr][nc] == self.EMPTY
                    ):
                        nearby.add((nr, nc))
        return sorted(nearby) if nearby else empties

    def minimax(
        self,
        is_maximizing: bool,
        depth: int,
        depth_limit: int,
        alpha: float,
        beta: float,
    ) -> int:
        terminal = self._evaluate_terminal(depth)
        if terminal is not None:
            return terminal
        if depth >= depth_limit:
            return self._heuristic()

        moves = self._candidate_moves()

        if is_maximizing:
            best_score = -math.inf
            for row, col in moves:
                self.board[row][col] = self.COMPUTER
                best_score = max(
                    best_score,
                    self.minimax(False, depth + 1, depth_limit, alpha, beta),
                )
                self.board[row][col] = self.EMPTY
                alpha = max(alpha, best_score)
                if beta <= alpha:
                    break
            return int(best_score)

        best_score = math.inf
        for row, col in moves:
            self.board[row][col] = self.HUMAN
            best_score = min(
                best_score,
                self.minimax(True, depth + 1, depth_limit, alpha, beta),
            )
            self.board[row][col] = self.EMPTY
            beta = min(beta, best_score)
            if beta <= alpha:
                break
        return int(best_score)

    def find_winning_move(self, mark: str) -> Optional[tuple[int, int]]:
        for row, col in self.empty_cells():
            self.board[row][col] = mark
            won = self.winning_mark() == mark
            self.board[row][col] = self.EMPTY
            if won:
                return row, col
        return None

    def computer_move(self) -> tuple[int, int]:
        """즉시 승리/차단 후, Minimax(필요 시 깊이 제한)로 최적 수를 고른다."""
        win_move = self.find_winning_move(self.COMPUTER)
        if win_move is not None:
            return win_move

        block_move = self.find_winning_move(self.HUMAN)
        if block_move is not None:
            return block_move

        depth_limit = self._search_depth()
        best_score = -math.inf
        best_move: Optional[tuple[int, int]] = None

        for row, col in self._candidate_moves():
            self.board[row][col] = self.COMPUTER
            score = self.minimax(
                is_maximizing=False,
                depth=0,
                depth_limit=depth_limit,
                alpha=-math.inf,
                beta=math.inf,
            )
            self.board[row][col] = self.EMPTY

            if score > best_score:
                best_score = score
                best_move = (row, col)

        if best_move is None:
            raise RuntimeError("둘 수 있는 칸이 없습니다.")
        return best_move


class TicTacToeApp:
    """가변 보드 크기(3~10)를 지원하는 Tkinter GUI."""

    BG = "#f0f4f8"
    PANEL = "#1e293b"
    BUTTON_BG = "#ffffff"
    BUTTON_ACTIVE = "#e2e8f0"
    BUTTON_DISABLED_BG = "#f8fafc"
    X_COLOR = "#2563eb"
    O_COLOR = "#dc2626"
    TEXT = "#0f172a"
    MUTED = "#64748b"
    ACCENT = "#334155"

    def __init__(self, root: tk.Tk) -> None:
        self.root = root
        self.board_size = 3
        self.game = TicTacToe(self.board_size)
        self.buttons: list[list[tk.Button]] = []
        self.game_over = False
        self.waiting_for_computer = False
        self.size_var = tk.StringVar(value=str(self.board_size))

        self.root.title("Tic Tac Toe")
        self.root.configure(bg=self.BG)
        self.root.resizable(False, False)

        self.title_font = tkfont.Font(family="Segoe UI Semibold", size=22)
        self.status_font = tkfont.Font(family="Segoe UI", size=12)
        self.legend_font = tkfont.Font(family="Segoe UI Semibold", size=12)
        self.restart_font = tkfont.Font(family="Segoe UI Semibold", size=11)

        self._build_ui()
        self._rebuild_board()
        self._set_status("당신(X) 차례입니다. 칸을 클릭하세요.")

    def _cell_metrics(self) -> tuple[int, int, int, int]:
        """보드 크기에 맞춰 칸 최소 크기, 글꼴, 내부 여백을 계산한다."""
        size = self.board_size
        if size <= 3:
            return 96, 36, 18, 5
        if size <= 5:
            return 72, 28, 10, 4
        if size <= 7:
            return 56, 20, 6, 3
        return 44, 16, 3, 2

    def _build_ui(self) -> None:
        self.frame = tk.Frame(self.root, bg=self.BG, padx=28, pady=24)
        self.frame.pack()

        tk.Label(
            self.frame,
            text="Tic Tac Toe",
            font=self.title_font,
            fg=self.TEXT,
            bg=self.BG,
        ).pack(pady=(0, 8))

        menu_row = tk.Frame(self.frame, bg=self.BG)
        menu_row.pack(pady=(0, 10))

        tk.Label(
            menu_row,
            text="보드 크기",
            font=self.status_font,
            fg=self.MUTED,
            bg=self.BG,
        ).pack(side=tk.LEFT, padx=(0, 8))

        size_values = [str(n) for n in range(TicTacToe.MIN_SIZE, TicTacToe.MAX_SIZE + 1)]
        size_menu = ttk.Combobox(
            menu_row,
            textvariable=self.size_var,
            values=size_values,
            width=4,
            state="readonly",
            justify="center",
        )
        size_menu.pack(side=tk.LEFT)
        size_menu.bind("<<ComboboxSelected>>", self.on_size_selected)

        tk.Label(
            menu_row,
            text="칸 (한 줄을 채우면 승리)",
            font=self.status_font,
            fg=self.MUTED,
            bg=self.BG,
        ).pack(side=tk.LEFT, padx=(8, 0))

        legend = tk.Frame(self.frame, bg=self.BG)
        legend.pack(pady=(0, 10))
        tk.Label(
            legend,
            text="당신 ",
            font=self.status_font,
            fg=self.MUTED,
            bg=self.BG,
        ).pack(side=tk.LEFT)
        tk.Label(
            legend,
            text="X",
            font=self.legend_font,
            fg=self.X_COLOR,
            bg=self.BG,
        ).pack(side=tk.LEFT)
        tk.Label(
            legend,
            text="   컴퓨터 ",
            font=self.status_font,
            fg=self.MUTED,
            bg=self.BG,
        ).pack(side=tk.LEFT)
        tk.Label(
            legend,
            text="O",
            font=self.legend_font,
            fg=self.O_COLOR,
            bg=self.BG,
        ).pack(side=tk.LEFT)

        self.status_var = tk.StringVar()
        tk.Label(
            self.frame,
            textvariable=self.status_var,
            font=self.status_font,
            fg=self.ACCENT,
            bg=self.BG,
        ).pack(pady=(0, 16))

        self.board_container = tk.Frame(self.frame, bg=self.BG)
        self.board_container.pack()

        tk.Button(
            self.frame,
            text="다시 시작",
            font=self.restart_font,
            bg=self.PANEL,
            fg="#ffffff",
            activebackground="#0f172a",
            activeforeground="#ffffff",
            relief=tk.FLAT,
            bd=0,
            cursor="hand2",
            padx=28,
            pady=10,
            command=self.restart,
        ).pack(pady=(18, 0))

    def _clear_board_widgets(self) -> None:
        for child in self.board_container.winfo_children():
            child.destroy()
        self.buttons = []

    def _rebuild_board(self) -> None:
        self._clear_board_widgets()
        cell_size, font_size, ipad, gap = self._cell_metrics()
        cell_font = tkfont.Font(family="Segoe UI Semibold", size=font_size)

        board_frame = tk.Frame(self.board_container, bg=self.PANEL, padx=10, pady=10)
        board_frame.pack()

        for row in range(self.board_size):
            board_frame.grid_rowconfigure(row, minsize=cell_size, weight=1)
            button_row: list[tk.Button] = []
            for col in range(self.board_size):
                board_frame.grid_columnconfigure(col, minsize=cell_size, weight=1)
                button = tk.Button(
                    board_frame,
                    text="",
                    width=3,
                    height=1,
                    font=cell_font,
                    bg=self.BUTTON_BG,
                    activebackground=self.BUTTON_ACTIVE,
                    activeforeground=self.X_COLOR,
                    disabledforeground=self.MUTED,
                    relief=tk.FLAT,
                    bd=0,
                    highlightthickness=0,
                    cursor="hand2",
                    command=lambda r=row, c=col: self.on_cell_click(r, c),
                )
                button.grid(
                    row=row,
                    column=col,
                    padx=gap,
                    pady=gap,
                    ipadx=ipad,
                    ipady=ipad,
                    sticky="nsew",
                )
                button_row.append(button)
            self.buttons.append(button_row)

    def on_size_selected(self, _event: object = None) -> None:
        new_size = int(self.size_var.get())
        if new_size == self.board_size:
            return

        board_has_moves = any(
            cell != TicTacToe.EMPTY for row in self.game.board for cell in row
        )
        if board_has_moves:
            confirmed = messagebox.askyesno(
                "보드 크기 변경",
                f"{new_size}x{new_size} 보드로 새 게임을 시작할까요?\n진행 중인 판은 초기화됩니다.",
                parent=self.root,
            )
            if not confirmed:
                self.size_var.set(str(self.board_size))
                return

        self.board_size = new_size
        self.game.set_size(new_size)
        self.game_over = False
        self.waiting_for_computer = False
        self._rebuild_board()
        self._set_status(f"{new_size}x{new_size} 보드 — 당신(X) 차례입니다.")

    def _set_status(self, message: str) -> None:
        self.status_var.set(message)

    def _mark_color(self, mark: str) -> str:
        return self.X_COLOR if mark == TicTacToe.HUMAN else self.O_COLOR

    def _update_button(self, row: int, col: int, mark: str) -> None:
        color = self._mark_color(mark)
        button = self.buttons[row][col]
        button.configure(
            text=mark,
            fg=color,
            bg=self.BUTTON_DISABLED_BG,
            state=tk.DISABLED,
            disabledforeground=color,
        )

    def _disable_board(self) -> None:
        for row in self.buttons:
            for button in row:
                button.configure(state=tk.DISABLED)

    def _result_message(self, result: str) -> str:
        if result == TicTacToe.HUMAN:
            return "사용자 승리"
        if result == TicTacToe.COMPUTER:
            return "컴퓨터 승리"
        return "무승부"

    def _finish_game(self, result: str) -> None:
        self.game_over = True
        self._disable_board()

        message = self._result_message(result)
        self._set_status(message)

        restart = messagebox.askyesno(
            "게임 종료",
            f"{message}\n\n다시 시작하시겠습니까?",
            parent=self.root,
        )
        if restart:
            self.restart()
        else:
            self._set_status(f"{message} — 다시 시작 버튼을 누를 수 있습니다.")

    def on_cell_click(self, row: int, col: int) -> None:
        if self.game_over or self.waiting_for_computer:
            return
        if self.game.is_occupied(row, col):
            return

        self.game.place_mark(row, col, TicTacToe.HUMAN)
        self._update_button(row, col, TicTacToe.HUMAN)

        result = self.game.get_result()
        if result is not None:
            self._finish_game(result)
            return

        self.waiting_for_computer = True
        self._set_status("컴퓨터가 생각 중...")
        delay = 200 if self.board_size <= 4 else 50
        self.root.after(delay, self._play_computer_move)

    def _play_computer_move(self) -> None:
        if self.game_over:
            self.waiting_for_computer = False
            return

        row, col = self.game.computer_move()
        self.game.place_mark(row, col, TicTacToe.COMPUTER)
        self._update_button(row, col, TicTacToe.COMPUTER)

        result = self.game.get_result()
        self.waiting_for_computer = False
        if result is not None:
            self._finish_game(result)
            return

        self._set_status("당신(X) 차례입니다. 칸을 클릭하세요.")

    def restart(self) -> None:
        self.game.reset()
        self.game_over = False
        self.waiting_for_computer = False
        for row in range(self.board_size):
            for col in range(self.board_size):
                button = self.buttons[row][col]
                button.configure(
                    text="",
                    state=tk.NORMAL,
                    fg=self.X_COLOR,
                    bg=self.BUTTON_BG,
                    disabledforeground=self.MUTED,
                )
        self._set_status("당신(X) 차례입니다. 칸을 클릭하세요.")

    def play(self) -> None:
        self.root.mainloop()


def main() -> None:
    root = tk.Tk()
    app = TicTacToeApp(root)
    app.play()


if __name__ == "__main__":
    main()
