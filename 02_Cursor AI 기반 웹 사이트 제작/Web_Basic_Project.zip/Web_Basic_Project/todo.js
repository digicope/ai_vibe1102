const todoForm = document.getElementById("todoForm");
const todoInput = document.getElementById("todoInput");
const todoList = document.getElementById("todoList");
const emptyState = document.getElementById("emptyState");

function updateEmptyState() {
  emptyState.classList.toggle("hidden", todoList.children.length > 0);
}

function createTodoItem(text) {
  const li = document.createElement("li");
  li.className = "todo-item";

  const span = document.createElement("span");
  span.textContent = text;

  const deleteBtn = document.createElement("button");
  deleteBtn.type = "button";
  deleteBtn.className = "delete-btn";
  deleteBtn.textContent = "삭제";
  deleteBtn.addEventListener("click", function () {
    li.remove();
    updateEmptyState();
  });

  li.append(span, deleteBtn);
  return li;
}

todoForm.addEventListener("submit", function (event) {
  event.preventDefault();

  const text = todoInput.value.trim();
  if (!text) {
    return;
  }

  todoList.appendChild(createTodoItem(text));
  todoInput.value = "";
  todoInput.focus();
  updateEmptyState();
});

updateEmptyState();
