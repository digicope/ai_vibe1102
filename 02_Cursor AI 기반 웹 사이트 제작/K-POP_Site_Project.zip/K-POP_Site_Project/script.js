const thanksButton = document.getElementById("thanks-btn");

if (thanksButton) {
  thanksButton.addEventListener("click", function () {
    alert("K-POP을 사랑해주셔서 감사합니다!");
  });
}

const contactForm = document.getElementById("contact-form");
const nameInput = document.getElementById("contact-name");
const emailInput = document.getElementById("contact-email");
const messageInput = document.getElementById("contact-message");
const nameError = document.getElementById("name-error");
const emailError = document.getElementById("email-error");
const messageError = document.getElementById("message-error");
const formStatus = document.getElementById("form-status");

const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

function setError(input, errorElement, message) {
  input.classList.add("is-invalid");
  errorElement.hidden = false;
  errorElement.textContent = message;
}

function clearError(input, errorElement) {
  input.classList.remove("is-invalid");
  errorElement.hidden = true;
  errorElement.textContent = "";
}

function clearFormStatus() {
  formStatus.hidden = true;
  formStatus.textContent = "";
  formStatus.classList.remove("is-success");
}

function validateContactForm() {
  let isValid = true;

  clearError(nameInput, nameError);
  clearError(emailInput, emailError);
  clearError(messageInput, messageError);
  clearFormStatus();

  const name = nameInput.value.trim();
  const email = emailInput.value.trim();
  const message = messageInput.value.trim();

  if (!name) {
    setError(nameInput, nameError, "이름을 입력해 주세요.");
    isValid = false;
  }

  if (!email) {
    setError(emailInput, emailError, "이메일을 입력해 주세요.");
    isValid = false;
  } else if (!emailPattern.test(email)) {
    setError(emailInput, emailError, "올바른 이메일 형식으로 입력해 주세요. (예: name@email.com)");
    isValid = false;
  }

  if (!message) {
    setError(messageInput, messageError, "메시지를 입력해 주세요.");
    isValid = false;
  }

  return isValid;
}

if (contactForm) {
  contactForm.addEventListener("submit", function (event) {
    event.preventDefault();

    if (!validateContactForm()) {
      return;
    }

    formStatus.hidden = false;
    formStatus.classList.add("is-success");
    formStatus.textContent = "메시지가 전송되었습니다. 감사합니다!";
    contactForm.reset();
  });

  [nameInput, emailInput, messageInput].forEach(function (input) {
    input.addEventListener("input", function () {
      if (input === nameInput) clearError(nameInput, nameError);
      if (input === emailInput) clearError(emailInput, emailError);
      if (input === messageInput) clearError(messageInput, messageError);
      clearFormStatus();
    });
  });
}
