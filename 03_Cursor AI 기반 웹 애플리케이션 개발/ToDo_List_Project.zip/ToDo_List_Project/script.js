document.addEventListener("DOMContentLoaded", () => {
  const STORAGE_KEY = "todo-list-items";

  const dateInput = document.getElementById("todo-date");
  const todoForm = document.getElementById("todo-form");
  const todoInput = document.getElementById("todo-input");
  const todoList = document.getElementById("todo-list");
  const addButton = document.getElementById("todo-add");
  const clearButton = document.getElementById("todo-clear");
  const filterButtons = document.querySelectorAll(".todo-filter");
  const calendarTitle = document.getElementById("calendar-title");
  const calendarDays = document.getElementById("calendar-days");
  const calendarPrev = document.getElementById("calendar-prev");
  const calendarNext = document.getElementById("calendar-next");

  if (
    !dateInput ||
    !todoForm ||
    !todoInput ||
    !todoList ||
    !addButton ||
    !clearButton ||
    filterButtons.length === 0 ||
    !calendarTitle ||
    !calendarDays ||
    !calendarPrev ||
    !calendarNext
  ) {
    console.error("할 일 목록에 필요한 요소를 찾지 못했습니다.");
    return;
  }

  let currentFilter = "all";
  let viewYear;
  let viewMonth;

  function formatDate(year, month, day) {
    return `${year}-${String(month + 1).padStart(2, "0")}-${String(day).padStart(2, "0")}`;
  }

  function getTodayString() {
    const today = new Date();
    return formatDate(today.getFullYear(), today.getMonth(), today.getDate());
  }

  function parseDateValue(value) {
    const [year, month, day] = value.split("-").map(Number);
    return { year, month: month - 1, day };
  }

  function setTodayDate() {
    dateInput.value = getTodayString();
  }

  function syncViewFromSelectedDate() {
    const { year, month } = parseDateValue(getSelectedDate());
    viewYear = year;
    viewMonth = month;
  }

  function loadTodos() {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (!raw) {
        return [];
      }

      const parsed = JSON.parse(raw);
      return Array.isArray(parsed) ? parsed : [];
    } catch (error) {
      console.error("LocalStorage에서 할 일을 불러오지 못했습니다.", error);
      return [];
    }
  }

  function saveTodos(todos) {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(todos));
  }

  function getSelectedDate() {
    return dateInput.value;
  }

  function createTodoItem(todo) {
    const item = document.createElement("li");
    item.className = "todo-item";
    item.dataset.id = todo.id;

    if (todo.completed) {
      item.classList.add("todo-item--completed");
    }

    const checkButton = document.createElement("button");
    checkButton.className = "todo-item__check";
    checkButton.type = "button";
    checkButton.setAttribute("aria-label", "완료 표시");
    checkButton.setAttribute("aria-pressed", String(Boolean(todo.completed)));
    checkButton.innerHTML = `
      <svg class="todo-item__check-icon" viewBox="0 0 16 16" aria-hidden="true">
        <path d="M3.2 8.2 6.4 11.4 12.8 4.6" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/>
      </svg>
    `;

    const textSpan = document.createElement("span");
    textSpan.className = "todo-item__text";
    textSpan.textContent = todo.text;

    const deleteButton = document.createElement("button");
    deleteButton.className = "todo-item__delete";
    deleteButton.type = "button";
    deleteButton.setAttribute("aria-label", "삭제");
    deleteButton.innerHTML = `
      <svg class="todo-item__delete-icon" viewBox="0 0 24 24" aria-hidden="true">
        <path d="M9 3h6M4 7h16M8 7v12a2 2 0 0 0 2 2h4a2 2 0 0 0 2-2V7M10 11v6M14 11v6" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/>
      </svg>
    `;

    function toggleCompleted() {
      const todos = loadTodos();
      const target = todos.find((entry) => entry.id === todo.id);
      if (!target) {
        return;
      }

      target.completed = !target.completed;
      saveTodos(todos);
      renderTodos();
    }

    checkButton.addEventListener("click", (event) => {
      event.stopPropagation();
      toggleCompleted();
    });

    textSpan.addEventListener("click", toggleCompleted);

    deleteButton.addEventListener("click", (event) => {
      event.stopPropagation();
      deleteTodo(todo.id);
    });

    item.appendChild(checkButton);
    item.appendChild(textSpan);
    item.appendChild(deleteButton);
    return item;
  }

  function getFilteredTodos() {
    const selectedDate = getSelectedDate();

    return loadTodos()
      .filter((todo) => todo.date === selectedDate)
      .filter((todo) => {
        if (currentFilter === "completed") {
          return todo.completed;
        }
        if (currentFilter === "active") {
          return !todo.completed;
        }
        return true;
      });
  }

  function getTodoCountsByDate() {
    return loadTodos().reduce((counts, todo) => {
      counts[todo.date] = (counts[todo.date] || 0) + 1;
      return counts;
    }, {});
  }

  function renderTodos() {
    const todos = getFilteredTodos();
    todoList.replaceChildren();
    todos.forEach((todo) => {
      todoList.appendChild(createTodoItem(todo));
    });
  }

  function renderCalendar() {
    const selectedDate = getSelectedDate();
    const today = getTodayString();
    const todoCounts = getTodoCountsByDate();
    const firstDay = new Date(viewYear, viewMonth, 1).getDay();
    const daysInMonth = new Date(viewYear, viewMonth + 1, 0).getDate();

    calendarTitle.textContent = `${viewYear}년 ${viewMonth + 1}월`;
    calendarDays.replaceChildren();

    for (let i = 0; i < firstDay; i += 1) {
      const empty = document.createElement("button");
      empty.className = "calendar__day";
      empty.type = "button";
      empty.disabled = true;
      empty.setAttribute("aria-hidden", "true");
      calendarDays.appendChild(empty);
    }

    for (let day = 1; day <= daysInMonth; day += 1) {
      const dateValue = formatDate(viewYear, viewMonth, day);
      const weekday = (firstDay + day - 1) % 7;
      const count = todoCounts[dateValue] || 0;
      const button = document.createElement("button");
      button.className = "calendar__day";
      button.type = "button";
      button.dataset.date = dateValue;
      button.setAttribute(
        "aria-label",
        count > 0 ? `${dateValue}, 할 일 ${count}개` : dateValue
      );

      const dayNumber = document.createElement("span");
      dayNumber.className = "calendar__day-number";
      dayNumber.textContent = String(day);
      button.appendChild(dayNumber);

      if (count > 0) {
        const badge = document.createElement("span");
        badge.className = "calendar__day-count";
        badge.textContent = String(count);
        button.appendChild(badge);
        button.classList.add("calendar__day--has-todos");
      }

      if (weekday === 0) {
        button.classList.add("calendar__day--sunday");
      }
      if (weekday === 6) {
        button.classList.add("calendar__day--saturday");
      }
      if (dateValue === today) {
        button.classList.add("calendar__day--today");
      }
      if (dateValue === selectedDate) {
        button.classList.add("calendar__day--selected");
        button.setAttribute("aria-current", "date");
      }

      button.addEventListener("click", () => {
        dateInput.value = dateValue;
        renderCalendar();
        renderTodos();
      });

      calendarDays.appendChild(button);
    }
  }

  function changeMonth(offset) {
    const next = new Date(viewYear, viewMonth + offset, 1);
    viewYear = next.getFullYear();
    viewMonth = next.getMonth();
    renderCalendar();
  }

  function addTodo(event) {
    if (event) {
      event.preventDefault();
    }

    const text = todoInput.value.trim();
    if (!text) {
      todoInput.focus();
      return;
    }

    const todos = loadTodos();
    todos.push({
      id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
      text,
      date: getSelectedDate(),
      completed: false,
    });
    saveTodos(todos);

    todoInput.value = "";
    todoInput.focus();
    renderCalendar();
    renderTodos();
  }

  function deleteTodo(id) {
    const todos = loadTodos().filter((todo) => todo.id !== id);
    saveTodos(todos);
    renderCalendar();
    renderTodos();
  }

  function clearAllTodos() {
    saveTodos([]);
    renderCalendar();
    renderTodos();
  }

  function setFilter(filter) {
    currentFilter = filter;

    filterButtons.forEach((button) => {
      button.classList.toggle("is-active", button.dataset.filter === filter);
    });

    renderTodos();
  }

  setTodayDate();
  syncViewFromSelectedDate();
  renderCalendar();
  renderTodos();

  todoForm.addEventListener("submit", addTodo);
  addButton.addEventListener("click", addTodo);
  clearButton.addEventListener("click", clearAllTodos);
  calendarPrev.addEventListener("click", () => changeMonth(-1));
  calendarNext.addEventListener("click", () => changeMonth(1));

  dateInput.addEventListener("change", () => {
    syncViewFromSelectedDate();
    renderCalendar();
    renderTodos();
  });

  filterButtons.forEach((button) => {
    button.addEventListener("click", () => {
      setFilter(button.dataset.filter);
    });
  });
});
