"""
weather_service.py
OpenWeatherMap API를 사용하여 현재 날씨 및 예보 정보를 조회하고 한국어 메시지를 구성하는 모듈
"""

import os
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Dict, Any, Optional, Tuple, List
import requests
from dotenv import load_dotenv

# 환경변수 로드 (.env 우선순위: c:\env\.env -> 프로젝트 루트 .env)
DEFAULT_ENV_PATH = Path(r"c:\env\.env")
if DEFAULT_ENV_PATH.exists():
    load_dotenv(dotenv_path=DEFAULT_ENV_PATH)
else:
    load_dotenv()

# 한국 주요 도시 한글-영문 매핑 (사용자 편의성 향상)
KOREAN_CITY_MAP = {
    "서울": "Seoul",
    "부산": "Busan",
    "인천": "Incheon",
    "대구": "Daegu",
    "대전": "Daejeon",
    "광주": "Gwangju",
    "울산": "Ulsan",
    "수원": "Suwon",
    "제주": "Jeju",
    "제주시": "Jeju",
    "서귀포": "Seogwipo",
    "성남": "Seongnam",
    "고양": "Goyang",
    "용인": "Yongin",
    "부천": "Bucheon",
    "안산": "Ansan",
    "전주": "Jeonju",
    "천안": "Cheonan",
    "청주": "Cheongju",
    "포항": "Pohang",
    "창원": "Changwon",
    "춘천": "Chuncheon",
    "강릉": "Gangneung",
    "원주": "Wonju",
    "여수": "Yeosu",
    "순천": "Suncheon",
    "경주": "Gyeongju",
    "세종": "Sejong"
}


class WeatherService:
    """OpenWeatherMap 날씨 조회 및 메시지 포맷팅 서비스"""

    CURRENT_WEATHER_URL = "https://api.openweathermap.org/data/2.5/weather"
    FORECAST_URL = "https://api.openweathermap.org/data/2.5/forecast"

    def __init__(self):
        self.api_key = os.getenv("OPENWEATHERMAP_API_KEY", "").strip()

    def is_configured(self) -> bool:
        """날씨 API 키 설정 여부 확인"""
        return bool(self.api_key)

    def normalize_city_name(self, city_input: str) -> str:
        """한글 도시명을 표준 영문 도시명으로 변환하거나 그대로 반환"""
        clean_input = city_input.strip()
        return KOREAN_CITY_MAP.get(clean_input, clean_input)

    def get_current_weather(self, city_name: str) -> Tuple[bool, str, Optional[Dict[str, Any]]]:
        """현재 날씨 조회"""
        if not self.is_configured():
            return False, "OPENWEATHERMAP_API_KEY 가 설정되지 않았습니다. c:\\env\\.env 파일을 확인해주세요.", None

        city_query = self.normalize_city_name(city_name)
        params = {
            "q": city_query,
            "appid": self.api_key,
            "units": "metric",
            "lang": "kr"
        }

        try:
            response = requests.get(self.CURRENT_WEATHER_URL, params=params, timeout=10)
            data = response.json() if response.content else {}

            if response.status_code == 200:
                return True, "현재 날씨 조회 성공", data

            error_msg = self._parse_weather_error(response.status_code, data, city_name)
            return False, error_msg, None

        except requests.exceptions.RequestException as e:
            return False, f"날씨 API 서버와 통신 중 네트워크 오류가 발생했습니다: {str(e)}", None

    def get_forecast(self, city_name: str) -> Tuple[bool, str, Optional[Dict[str, Any]]]:
        """5일 / 3시간 예보 조회 (OpenWeatherMap Free Tier 표준 지원)"""
        if not self.is_configured():
            return False, "OPENWEATHERMAP_API_KEY 가 설정되지 않았습니다.", None

        city_query = self.normalize_city_name(city_name)
        params = {
            "q": city_query,
            "appid": self.api_key,
            "units": "metric",
            "lang": "kr"
        }

        try:
            response = requests.get(self.FORECAST_URL, params=params, timeout=10)
            data = response.json() if response.content else {}

            if response.status_code == 200:
                return True, "예보 데이터 조회 성공", data

            error_msg = self._parse_weather_error(response.status_code, data, city_name)
            return False, error_msg, None

        except requests.exceptions.RequestException as e:
            return False, f"예보 API 통신 오류: {str(e)}", None

    def create_weather_report_message(self, city_input: str) -> Tuple[bool, str]:
        """
        현재 날씨와 내일 예보를 실제 API 데이터에 기반하여 정직하게 결합한 한국어 카카오톡 메시지 생성
        """
        # 1. 현재 날씨 조회
        ok_cur, msg_cur, current_data = self.get_current_weather(city_input)
        if not ok_cur or not current_data:
            return False, msg_cur

        # 현재 날씨 파싱
        city_display = current_data.get("name", city_input)
        country = current_data.get("sys", {}).get("country", "")
        weather_desc = current_data.get("weather", [{}])[0].get("description", "정보 없음")
        main_info = current_data.get("main", {})
        temp = main_info.get("temp")
        feels_like = main_info.get("feels_like")
        temp_min = main_info.get("temp_min")
        temp_max = main_info.get("temp_max")
        humidity = main_info.get("humidity")
        wind_speed = current_data.get("wind", {}).get("speed")

        # 타임스탬프 계산 (현지 타임존 오프셋 반영)
        timezone_offset = current_data.get("timezone", 32400)  # 기본 KST (9시간=32400초)
        tz = timezone(timedelta(seconds=timezone_offset))
        now_dt = datetime.now(tz)
        time_str = now_dt.strftime("%Y-%m-%d %H:%M")

        # 메시지 헤더 구성
        report_lines = [
            f"[🌤️ 날씨 알림 - {city_display} ({country})]",
            f"기준 시간: {time_str}",
            "",
            f"▶ 현재 날씨: {weather_desc}",
            f"• 기온: {temp:.1f}°C (체감 {feels_like:.1f}°C)" if temp is not None else "",
            f"• 오늘 범위: 최저 {temp_min:.1f}°C / 최고 {temp_max:.1f}°C" if (temp_min is not None and temp_max is not None) else "",
            f"• 습도: {humidity}% | 풍속: {wind_speed} m/s" if (humidity is not None and wind_speed is not None) else ""
        ]

        # 2. 5일/3시간 예보를 통한 내일 날씨 요약 추출
        ok_fore, _, forecast_data = self.get_forecast(city_input)
        if ok_fore and forecast_data and "list" in forecast_data:
            tomorrow_date_str = (now_dt + timedelta(days=1)).strftime("%Y-%m-%d")
            tomorrow_items: List[Dict[str, Any]] = []

            for item in forecast_data.get("list", []):
                dt_txt = item.get("dt_txt", "")  # 예: "2026-10-31 12:00:00"
                if dt_txt.startswith(tomorrow_date_str):
                    tomorrow_items.append(item)

            if tomorrow_items:
                t_temps = [item.get("main", {}).get("temp") for item in tomorrow_items if item.get("main", {}).get("temp") is not None]
                t_weather_descs = [item.get("weather", [{}])[0].get("description", "") for item in tomorrow_items]
                t_pops = [item.get("pop", 0) for item in tomorrow_items if item.get("pop") is not None]

                # 가장 빈번한 날씨 상태 또는 대표 날씨 추출
                primary_weather = max(set(t_weather_descs), key=t_weather_descs.count) if t_weather_descs else "정보 없음"
                t_min = min(t_temps) if t_temps else None
                t_max = max(t_temps) if t_temps else None
                max_pop_percent = int(max(t_pops) * 100) if t_pops else None

                report_lines.append("")
                report_lines.append(f"▶ 내일 예보 ({(now_dt + timedelta(days=1)).strftime('%m/%d')}):")
                report_lines.append(f"• 날씨: {primary_weather}")
                if t_min is not None and t_max is not None:
                    report_lines.append(f"• 예상 기온: 최저 {t_min:.1f}°C / 최고 {t_max:.1f}°C")
                if max_pop_percent is not None:
                    report_lines.append(f"• 최고 강수확률: {max_pop_percent}%")

        # 빈 줄 정리 후 반환
        final_message = "\n".join([line for line in report_lines if line != ""])
        return True, final_message

    def _parse_weather_error(self, status_code: int, error_data: Dict[str, Any], city_name: str) -> str:
        """OpenWeatherMap 응답 상태 코드에 따른 원인 및 해결 가이드"""
        code = error_data.get("cod")
        msg = error_data.get("message", "알 수 없는 오류")

        guidance = [f"[OpenWeatherMap 날씨 API 오류 - 상태코드: {status_code}]"]
        guidance.append(f"오류 메시지: {msg}")

        if status_code == 401:
            guidance.append(
                "\n■ 원인 및 해결 방법:\n"
                " - OpenWeatherMap API 키가 유효하지 않거나 만료되었습니다.\n"
                " - OpenWeatherMap(https://openweathermap.org)에 로그인하여 API Key가 올바른지 확인하세요.\n"
                " - 신규 발급받은 API 키의 경우 활성화되기까지 약 10분~30분 정도 소요될 수 있습니다."
            )
        elif status_code == 404:
            guidance.append(
                f"\n■ 원인 및 해결 방법:\n"
                f" - 입력하신 도시 '{city_name}'를 찾을 수 없습니다.\n"
                f" - 영문 도시명(예: Seoul, Busan, Tokyo, New York) 또는 'Seoul,KR' 형태로 입력해보세요."
            )
        elif status_code == 429:
            guidance.append(
                "\n■ 원인 및 해결 방법:\n"
                " - OpenWeatherMap 무료 호출 한도(분당 60회 / 일일 1,000회)를 초과했습니다.\n"
                " - 잠시 후 다시 시도해주세요."
            )
        else:
            guidance.append("\n■ 날씨 API 서버 요청 중 문제가 발생했습니다. 잠시 후 다시 시도해주세요.")

        return "\n".join(guidance)

