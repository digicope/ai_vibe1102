"""
app.py
카카오톡 '나에게 보내기' 및 OpenWeatherMap 날씨 전송 대화형 CLI 애플리케이션
"""

import sys
import secrets
import threading
import webbrowser
import logging
from typing import Optional
from flask import Flask, request, render_template_string
from werkzeug.serving import make_server

from kakao_client import KakaoAPIClient
from weather_service import WeatherService

# Flask 로그 레벨 낮추기
log = logging.getLogger('werkzeug')
log.setLevel(logging.ERROR)


class OAuthServerThread(threading.Thread):
    """OAuth 콜백을 수신하고 토큰을 교환한 뒤 자동으로 종료되는 로컬 HTTP 서버 스레드"""

    def __init__(self, host: str, port: int, kakao_client: KakaoAPIClient, expected_state: str):
        super().__init__(daemon=True)
        self.host = host
        self.port = port
        self.kakao_client = kakao_client
        self.expected_state = expected_state
        self.success = False
        self.result_message = ""
        self.completed_event = threading.Event()

        # Flask 앱 초기화
        self.app = Flask(__name__)
        self._register_routes()
        self.server = make_server(self.host, self.port, self.app)
        self.ctx = self.app.app_context()
        self.ctx.push()

    def _register_routes(self):
        @self.app.route('/callback', methods=['GET'])
        def callback():
            code = request.args.get('code')
            state = request.args.get('state')
            error = request.args.get('error')
            error_description = request.args.get('error_description', '')

            # 1. 인증 오류 반환 여부 확인
            if error:
                self.success = False
                self.result_message = f"카카오 인증 취소 또는 오류: {error} ({error_description})"
                self._schedule_shutdown()
                return render_template_string(HTML_ERROR, message=self.result_message)

            # 2. CSRF 방지용 State 검증
            if not state or state != self.expected_state:
                self.success = False
                self.result_message = "보안 검증 실패: OAuth state 값이 일치하지 않습니다 (CSRF 위험)."
                self._schedule_shutdown()
                return render_template_string(HTML_ERROR, message=self.result_message)

            # 3. 인가 코드 누락 여부 확인
            if not code:
                self.success = False
                self.result_message = "인가 코드(Authorization Code)가 전달되지 않았습니다."
                self._schedule_shutdown()
                return render_template_string(HTML_ERROR, message=self.result_message)

            # 4. 토큰 교환 요청
            ok, msg, _ = self.kakao_client.request_token_by_code(code)
            self.success = ok
            self.result_message = msg

            self._schedule_shutdown()

            if ok:
                return render_template_string(HTML_SUCCESS)
            else:
                return render_template_string(HTML_ERROR, message=msg)

    def _schedule_shutdown(self):
        """서버 종료 및 이벤트 설정"""
        self.completed_event.set()
        threading.Thread(target=self.server.shutdown, daemon=True).start()

    def run(self):
        self.server.serve_forever()


HTML_SUCCESS = """
<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <title>인증 완료 - 카카오 메시지 앱</title>
    <style>
        body { font-family: 'Malgun Gothic', sans-serif; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; background-color: #f7f7f7; }
        .card { background: white; padding: 40px; border-radius: 12px; box-shadow: 0 4px 15px rgba(0,0,0,0.1); text-align: center; max-width: 450px; }
        .icon { font-size: 50px; color: #FEE500; margin-bottom: 20px; }
        h2 { color: #333; margin-bottom: 10px; }
        p { color: #666; font-size: 15px; line-height: 1.5; }
        .badge { background: #fee500; color: #191919; padding: 6px 14px; border-radius: 20px; font-weight: bold; display: inline-block; margin-top: 15px; }
    </style>
</head>
<body>
    <div class="card">
        <div class="icon">💬</div>
        <h2>카카오 로그인 인증 완료!</h2>
        <p>토큰이 안전하게 발급 및 저장되었습니다.<br>이 브라우저 창을 닫고 콘솔 프로그램으로 돌아가세요.</p>
        <div class="badge">콘솔 메뉴에서 메시지를 전송해보세요</div>
    </div>
</body>
</html>
"""

HTML_ERROR = """
<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <title>인증 실패 - 카카오 메시지 앱</title>
    <style>
        body { font-family: 'Malgun Gothic', sans-serif; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; background-color: #fbf0f0; }
        .card { background: white; padding: 40px; border-radius: 12px; box-shadow: 0 4px 15px rgba(0,0,0,0.1); text-align: center; max-width: 480px; }
        .icon { font-size: 50px; color: #e74c3c; margin-bottom: 20px; }
        h2 { color: #c0392b; margin-bottom: 10px; }
        p { color: #555; font-size: 14px; line-height: 1.6; text-align: left; background: #fdf5f5; padding: 15px; border-radius: 8px; border-left: 4px solid #e74c3c; }
    </style>
</head>
<body>
    <div class="card">
        <div class="icon">⚠️</div>
        <h2>인증 처리에 실패하였습니다</h2>
        <p>{{ message }}</p>
        <span style="font-size: 13px; color: #888;">콘솔 화면의 가이드를 확인해주세요.</span>
    </div>
</body>
</html>
"""


def perform_kakao_login(client: KakaoAPIClient) -> None:
    """OAuth 2.0 웹 기반 인증 진행"""
    is_valid, msg = client.validate_config()
    if not is_valid:
        print("\n[환경변수 설정 오류]")
        print(msg)
        return

    # CSRF 방지용 랜덤 state 생성
    state = secrets.token_urlsafe(16)
    auth_url = client.get_authorization_url(state)

    print("\n" + "=" * 60)
    print("▶ [1단계] 로컬 OAuth 콜백 서버(http://localhost:8000)를 시작합니다...")
    server_thread = OAuthServerThread("127.0.0.1", 8000, client, state)
    
    try:
        server_thread.start()
    except OSError as e:
        print(f"\n[오류] 8000번 포트를 열 수 없습니다. 이미 다른 프로그램이 사용 중인지 확인하세요: {e}")
        return

    print("▶ [2단계] 기본 웹 브라우저에서 카카오 로그인 페이지를 엽니다.")
    print("   만약 자동으로 열리지 않는다면 아래 링크를 복사하여 브라우저에 붙여넣으세요:")
    print(f"   {auth_url}")
    print("=" * 60)

    webbrowser.open(auth_url)

    print("\n브라우저에서 로그인을 완료할 때까지 대기 중입니다... (콜백 수신 대기)")
    server_thread.completed_event.wait(timeout=180)  # 최대 3분 대기

    if not server_thread.completed_event.is_set():
        print("\n[시간 초과] 3분 동안 로그인이 완료되지 않아 인증 대기를 종료합니다.")
        server_thread.server.shutdown()
        return

    if server_thread.success:
        print("\n" + "=" * 60)
        print("✔ [인증 성공] 카카오 로그인 및 토큰 발급이 완료되었습니다!")
        print("  이제 메시지 보내기 메뉴를 이용하실 수 있습니다.")
        print("=" * 60)
    else:
        print("\n" + "=" * 60)
        print("✖ [인증 실패] 토큰 발급 중 문제가 발생했습니다.")
        print(f"  {server_thread.result_message}")
        print("=" * 60)


def send_test_message(client: KakaoAPIClient) -> None:
    """기본 테스트 메시지 전송"""
    print("\n" + "-" * 50)
    print("기본 테스트 메시지를 전송합니다...")
    default_text = "Python에서 보낸 카카오톡 테스트 메시지입니다.\n카카오 메시지 API 연동이 성공적으로 완료되었습니다!"
    
    success, result_msg = client.send_memo_message(
        text=default_text,
        web_url="https://developers.kakao.com",
        button_title="바로 확인"
    )

    if success:
        print(f"✔ {result_msg}")
    else:
        print(f"✖ [카카오톡 API 오류]\n{result_msg}")
    print("-" * 50)


def send_custom_message(client: KakaoAPIClient) -> None:
    """사용자가 직접 입력한 메시지 전송"""
    print("\n" + "-" * 50)
    print("카카오톡으로 보낼 메시지를 입력하세요 (빈 줄 입력 시 취소):")
    custom_text = input("▶ 메시지 내용: ").strip()

    if not custom_text:
        print("✖ 메시지 내용이 비어 있어 전송을 취소했습니다.")
        print("-" * 50)
        return

    custom_url = input("▶ 링크 URL (엔터 입력 시 https://developers.kakao.com): ").strip()
    if not custom_url:
        custom_url = "https://developers.kakao.com"

    custom_btn = input("▶ 버튼 텍스트 (엔터 입력 시 '자세히 보기'): ").strip()
    if not custom_btn:
        custom_btn = "자세히 보기"

    print("\n메시지를 전송하는 중...")
    success, result_msg = client.send_memo_message(
        text=custom_text,
        web_url=custom_url,
        button_title=custom_btn
    )

    if success:
        print(f"✔ {result_msg}")
    else:
        print(f"✖ [카카오톡 API 오류]\n{result_msg}")
    print("-" * 50)


def send_weather_message(client: KakaoAPIClient, weather_svc: WeatherService) -> None:
    """도시별 날씨 정보를 조회하여 카카오톡으로 전송"""
    print("\n" + "-" * 50)
    print("🌤️  OpenWeatherMap 날씨 정보 전송")
    print("-" * 50)

    # 1. 날씨 API 키 설정 여부 확인
    if not weather_svc.is_configured():
        print("✖ [날씨 API 미설정 안내]")
        print("  OPENWEATHERMAP_API_KEY 가 .env 파일에 설정되어 있지 않습니다.")
        print("  1) https://openweathermap.org 에서 무료 계정 생성 후 API 키 발급")
        print("  2) c:\\env\\.env 파일에 OPENWEATHERMAP_API_KEY=발급받은_키 추가")
        print("  (기본 카카오톡 메시지 기능은 이 키 없이도 정상 동작합니다.)")
        print("-" * 50)
        return

    # 2. 도시명 입력 받기
    city_input = input("▶ 조회할 도시명을 입력하세요 (기본값: Seoul / 예: 서울, 부산, Tokyo): ").strip()
    if not city_input:
        city_input = "Seoul"

    print(f"\n[{city_input}] 날씨 정보를 조회 중입니다...")
    
    # 3. 날씨 정보 조회 및 한국어 리포트 구성
    weather_ok, weather_result = weather_svc.create_weather_report_message(city_input)
    if not weather_ok:
        print(f"\n✖ [날씨 API 오류]\n{weather_result}")
        print("-" * 50)
        return

    # 4. 조회된 날씨 메시지 미리보기
    print("\n[조회된 날씨 메시지 미리보기]")
    print("=" * 45)
    print(weather_result)
    print("=" * 45)

    # 5. 카카오톡으로 전송
    print("\n카카오톡 '나에게 보내기'로 전송합니다...")
    kakao_ok, kakao_result = client.send_memo_message(
        text=weather_result,
        web_url="https://openweathermap.org",
        button_title="날씨 상세 보기"
    )

    if kakao_ok:
        print(f"✔ {kakao_result}")
    else:
        print(f"✖ [카카오톡 API 오류]\n{kakao_result}")

    print("-" * 50)


def print_banner():
    print("""
============================================================
   💬 카카오톡 '나에게 보내기' & 🌤️ 날씨 알림 발송 앱 💬
============================================================
""")


def main_menu():
    client = KakaoAPIClient()
    weather_svc = WeatherService()
    print_banner()

    # 카카오 설정 기본 검증 안내
    is_valid, msg = client.validate_config()
    if not is_valid:
        print("[알림] 카카오 환경변수 파일(c:\\env\\.env)이 준비되지 않았습니다.")
        print("       README.md 문서를 참고하여 REST API 키를 먼저 설정해주세요.\n")

    while True:
        auth_status = "인증됨(토큰 보유)" if client.is_authenticated() else "미인증(로그인 필요)"
        weather_status = "설정됨" if weather_svc.is_configured() else "미설정(키 필요)"

        print(f"\n[카카오 인증 상태: {auth_status} | 날씨 API: {weather_status}]")
        print("1. 카카오 로그인 인증 (OAuth)")
        print("2. 기본 테스트 메시지 보내기")
        print("3. 직접 입력한 메시지 보내기")
        print("4. 🌤️ 날씨 정보 조회 후 카카오톡으로 보내기")
        print("5. 종료")
        
        choice = input("\n메뉴를 선택하세요 (1-5): ").strip()

        if choice == "1":
            perform_kakao_login(client)
        elif choice == "2":
            send_test_message(client)
        elif choice == "3":
            send_custom_message(client)
        elif choice == "4":
            send_weather_message(client, weather_svc)
        elif choice == "5":
            print("\n프로그램을 종료합니다. 이용해주셔서 감사합니다.")
            sys.exit(0)
        else:
            print("\n잘못된 입력입니다. 1번부터 5번 사이의 숫자를 입력해주세요.")


if __name__ == "__main__":
    try:
        main_menu()
    except KeyboardInterrupt:
        print("\n\n프로그램을 강제 종료합니다.")
        sys.exit(0)
