"""
kakao_client.py
카카오 OAuth 2.0 인증 및 카카오톡 '나에게 보내기' API 클라이언트 모듈
"""

import os
import json
import urllib.parse
from pathlib import Path
from typing import Dict, Any, Optional, Tuple
import requests
from dotenv import load_dotenv

# 1. 환경변수 로드 (.env 우선순위: c:\env\.env -> 프로젝트 루트 .env)
DEFAULT_ENV_PATH = Path(r"c:\env\.env")
if DEFAULT_ENV_PATH.exists():
    load_dotenv(dotenv_path=DEFAULT_ENV_PATH)
else:
    load_dotenv()  # 현재 작업 디렉토리의 .env 로드

# 토큰 저장 파일 경로
TOKEN_FILE_PATH = Path("token_info.json")


class KakaoAPIClient:
    """카카오 OAuth 인증 및 메시지 전송 클라이언트"""

    AUTH_URL = "https://kauth.kakao.com/oauth/authorize"
    TOKEN_URL = "https://kauth.kakao.com/oauth/token"
    SEND_MEMO_URL = "https://kapi.kakao.com/v2/api/talk/memo/default/send"

    def __init__(self):
        self.client_id = os.getenv("KAKAO_REST_API_KEY", "").strip()
        self.client_secret = os.getenv("KAKAO_CLIENT_SECRET", "").strip()
        self.redirect_uri = os.getenv("KAKAO_REDIRECT_URI", "http://localhost:8000/callback").strip()

    def validate_config(self) -> Tuple[bool, str]:
        """환경변수 필수 설정값 검증"""
        if not self.client_id:
            return (
                False,
                "KAKAO_REST_API_KEY 가 설정되지 않았습니다.\n"
                "c:\\env\\.env 파일에 KAKAO_REST_API_KEY=your_key 형식으로 설정해주세요."
            )
        if not self.redirect_uri:
            return (
                False,
                "KAKAO_REDIRECT_URI 가 설정되지 않았습니다.\n"
                "기본값(http://localhost:8000/callback)을 c:\\env\\.env 에 등록해주세요."
            )
        return True, "설정이 유효합니다."

    def get_authorization_url(self, state: str) -> str:
        """카카오 로그인 인가 코드(Authorize Code) 발급용 URL 생성"""
        params = {
            "client_id": self.client_id,
            "redirect_uri": self.redirect_uri,
            "response_type": "code",
            "scope": "talk_message",
            "state": state
        }
        return f"{self.AUTH_URL}?{urllib.parse.urlencode(params)}"

    def request_token_by_code(self, code: str) -> Tuple[bool, str, Optional[Dict[str, Any]]]:
        """인가 코드를 이용해 액세스 토큰 및 리프레시 토큰 발급"""
        payload = {
            "grant_type": "authorization_code",
            "client_id": self.client_id,
            "redirect_uri": self.redirect_uri,
            "code": code
        }

        # Client Secret이 활성화되어 있는 경우 포함
        if self.client_secret:
            payload["client_secret"] = self.client_secret

        headers = {
            "Content-Type": "application/x-www-form-urlencoded;charset=utf-8"
        }

        try:
            response = requests.post(self.TOKEN_URL, data=payload, headers=headers, timeout=10)
            data = response.json()

            if response.status_code == 200:
                self.save_token_info(data)
                return True, "토큰 발급에 성공하였습니다.", data
            
            error_msg = self._parse_error_response(response.status_code, data)
            return False, error_msg, data

        except requests.exceptions.RequestException as e:
            return False, f"네트워크 통신 오류가 발생했습니다: {str(e)}", None

    def refresh_access_token(self) -> Tuple[bool, str]:
        """리프레시 토큰을 이용해 만료된 액세스 토큰 갱신"""
        token_info = self.load_token_info()
        refresh_token = token_info.get("refresh_token")

        if not refresh_token:
            return False, "저장된 리프레시 토큰이 없습니다. 메뉴 1번을 통해 다시 로그인해주세요."

        payload = {
            "grant_type": "refresh_token",
            "client_id": self.client_id,
            "refresh_token": refresh_token
        }

        if self.client_secret:
            payload["client_secret"] = self.client_secret

        headers = {
            "Content-Type": "application/x-www-form-urlencoded;charset=utf-8"
        }

        try:
            response = requests.post(self.TOKEN_URL, data=payload, headers=headers, timeout=10)
            data = response.json()

            if response.status_code == 200:
                # refresh_token은 응답에 없을 수도 있으므로 기존 값 보존
                updated_token = token_info.copy()
                updated_token["access_token"] = data["access_token"]
                updated_token["expires_in"] = data.get("expires_in", 0)
                if "refresh_token" in data:
                    updated_token["refresh_token"] = data["refresh_token"]
                if "refresh_token_expires_in" in data:
                    updated_token["refresh_token_expires_in"] = data["refresh_token_expires_in"]

                self.save_token_info(updated_token)
                return True, "액세스 토큰이 성공적으로 갱신되었습니다."
            
            error_msg = self._parse_error_response(response.status_code, data)
            return False, f"토큰 갱신 실패: {error_msg}\n재인증(로그인)을 진행해주세요."

        except requests.exceptions.RequestException as e:
            return False, f"토큰 갱신 통신 오류: {str(e)}"

    def send_memo_message(
        self,
        text: str,
        web_url: str = "https://developers.kakao.com",
        button_title: str = "바로 확인",
        retry_on_token_expiry: bool = True
    ) -> Tuple[bool, str]:
        """
        카카오톡 '나에게 보내기(메모)' 메시지 전송
        """
        if not text or not text.strip():
            return False, "메시지 내용이 비어 있어 전송할 수 없습니다."

        token_info = self.load_token_info()
        access_token = token_info.get("access_token")

        if not access_token:
            return False, "저장된 액세스 토큰이 없습니다. 먼저 메뉴 1번을 선택해 카카오 로그인을 완료해주세요."

        headers = {
            "Authorization": f"Bearer {access_token}",
            "Content-Type": "application/x-www-form-urlencoded;charset=utf-8"
        }

        # 기본 템플릿 JSON 구성 (피드/텍스트 형식)
        template_object = {
            "object_type": "text",
            "text": text.strip(),
            "link": {
                "web_url": web_url,
                "mobile_web_url": web_url
            },
            "button_title": button_title
        }

        data = {
            "template_object": json.dumps(template_object, ensure_ascii=False)
        }

        try:
            response = requests.post(self.SEND_MEMO_URL, headers=headers, data=data, timeout=10)
            res_json = response.json() if response.content else {}

            if response.status_code == 200:
                result_code = res_json.get("result_code", 0)
                if result_code == 0:
                    return True, "카카오톡 '나에게 보내기' 메시지가 성공적으로 전송되었습니다!"
                return False, f"메시지 전송 결과 비정상: {res_json}"

            # 401 Unauthorized (토큰 만료 등) 발생 시 토큰 자동 갱신 후 재시도
            if response.status_code == 401 and retry_on_token_expiry:
                refresh_ok, refresh_msg = self.refresh_access_token()
                if refresh_ok:
                    # 토큰 갱신 성공 -> 1회 재전송 시도
                    return self.send_memo_message(
                        text=text,
                        web_url=web_url,
                        button_title=button_title,
                        retry_on_token_expiry=False
                    )
                else:
                    return False, f"인증 만료 후 토큰 자동 갱신 실패:\n{refresh_msg}"

            error_msg = self._parse_error_response(response.status_code, res_json)
            return False, error_msg

        except requests.exceptions.RequestException as e:
            return False, f"메시지 전송 요청 중 네트워크 오류 발생: {str(e)}"

    def save_token_info(self, token_data: Dict[str, Any]) -> None:
        """토큰 정보를 로컬 파일에 안전하게 저장"""
        try:
            with open(TOKEN_FILE_PATH, "w", encoding="utf-8") as f:
                json.dump(token_data, f, ensure_ascii=False, indent=2)
        except Exception as e:
            print(f"[경고] 토큰 파일 저장 실패: {e}")

    def load_token_info(self) -> Dict[str, Any]:
        """로컬 파일에서 토큰 정보 로드"""
        if not TOKEN_FILE_PATH.exists():
            return {}
        try:
            with open(TOKEN_FILE_PATH, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return {}

    def is_authenticated(self) -> bool:
        """유효한 토큰 파일이 존재하는지 여부 확인"""
        token = self.load_token_info()
        return bool(token.get("access_token"))

    def _parse_error_response(self, status_code: int, error_data: Dict[str, Any]) -> str:
        """API 오류 코드 및 상태 코드 분석 후 사용자 친화적인 설명 반환"""
        error_code = error_data.get("code") or error_data.get("error_code")
        error_msg = error_data.get("msg") or error_data.get("error_description") or "알 수 없는 오류"

        guidance = []
        guidance.append(f"[오류 상태 코드: {status_code}]")
        if error_code:
            guidance.append(f"[오류 코드: {error_code}]")
        guidance.append(f"[오류 내용: {error_msg}]")
        guidance.append("\n■ 원인 분석 및 해결 가이드:")

        if status_code == 400:
            guidance.append(
                " - 잘못된 요청(Bad Request)입니다.\n"
                " - Redirect URI 또는 Client ID(REST API 키)가 카카오 개발자 콘솔 설정과 일치하는지 확인하세요.\n"
                " - KOE303 오류의 경우 카카오 개발자 콘솔 > '카카오 로그인' > 'Redirect URI'에 등록된 주소와 일치해야 합니다."
            )
        elif status_code == 401:
            guidance.append(
                " - 인증 실패(Unauthorized)입니다.\n"
                " - 액세스 토큰이 만료되었거나 올바르지 않습니다.\n"
                " - 메뉴 1번을 실행하여 카카오 로그인을 다시 진행해주세요."
            )
        elif status_code == 403:
            guidance.append(
                " - 권한 부족(Forbidden)입니다.\n"
                " - 카카오 개발자 콘솔 > '카카오 로그인' > '동의항목' 메뉴에서\n"
                "   [카카오톡 메시지 전송 (talk_message)] 동의 항목이 '이용 중 동의' 또는 '필수 동의'로 설정되어 있는지 확인하세요.\n"
                " - 카카오 개발자 콘솔 > '플랫폼' > Web 사이트 도메인에 'http://localhost:8000'이 등록되어 있는지 확인하세요."
            )
        elif status_code == 500:
            guidance.append(" - 카카오 서버 내부 오류입니다. 잠시 후 다시 시도해주세요.")
        else:
            guidance.append(" - 요청 처리 중 예기치 않은 상태 코드가 수신되었습니다.")

        return "\n".join(guidance)

