"""주식시세 JSON을 표로 정리하고 기술통계를 계산한다."""

from __future__ import annotations

from datetime import date, datetime
from typing import Any, Optional

import pandas as pd

COLUMN_MAP = {
    "basDt": "기준일자",
    "srtnCd": "단축코드",
    "isinCd": "ISIN코드",
    "itmsNm": "종목명",
    "mrktCtg": "시장구분",
    "clpr": "종가",
    "vs": "대비",
    "fltRt": "등락률",
    "mkp": "시가",
    "hipr": "고가",
    "lopr": "저가",
    "trqu": "거래량",
    "trPrc": "거래대금",
    "lstgStCnt": "상장주식수",
    "mrktTotAmt": "시가총액",
}

EXPECTED_COLUMNS = list(COLUMN_MAP.values())
INTEGER_CANDIDATES = ["종가", "대비", "시가", "고가", "저가", "거래량", "거래대금", "상장주식수", "시가총액"]
FLOAT_COLUMNS = ["등락률"]
TEXT_COLUMNS = ["단축코드", "ISIN코드", "종목명", "시장구분"]
STAT_COLUMNS = ["종가", "대비", "등락률", "시가", "고가", "저가", "거래량", "거래대금", "시가총액"]


class DataProcessingError(Exception):
    def __init__(self, message: str, hint: str = ""):
        super().__init__(message)
        self.hint = hint


def preprocess(records: list[dict]) -> dict:
    """레코드를 DataFrame으로 바꾸고 건수·결측·중복 정보를 함께 반환한다."""
    before_count = len(records)
    if before_count == 0:
        raise DataProcessingError(
            "수집된 데이터 행이 없습니다.",
            "기준일자를 최근 영업일로 바꾸거나, 종목명 조건을 비우고 다시 조회하세요. "
            "금융위원회 자료는 기준일 다음 영업일 13시 이후에 반영됩니다.",
        )

    frame = pd.DataFrame(records)
    unknown = [column for column in frame.columns if column not in COLUMN_MAP]
    frame = frame.rename(columns=COLUMN_MAP)
    missing_columns = [name for name in EXPECTED_COLUMNS if name not in frame.columns]
    if not any(name in frame.columns for name in EXPECTED_COLUMNS):
        raise DataProcessingError(
            "예상한 주식시세 컬럼이 없습니다.",
            "원본 응답의 필드명을 디버그 영역에서 확인하세요. "
            f"필요한 필드 예: {', '.join(list(COLUMN_MAP)[:6])}",
        )

    for column in TEXT_COLUMNS:
        if column in frame.columns:
            frame[column] = frame[column].map(_clean_text)

    conversion_errors: dict[str, int] = {}
    for column in INTEGER_CANDIDATES + FLOAT_COLUMNS:
        if column not in frame.columns:
            continue
        converted, failed = _to_number(frame[column])
        conversion_errors[column] = failed
        if column in INTEGER_CANDIDATES and _is_whole(converted):
            frame[column] = converted.round().astype("Int64")
        else:
            frame[column] = converted

    if "기준일자" in frame.columns:
        raw_dates = frame["기준일자"].map(_clean_text)
        parsed = pd.to_datetime(raw_dates, format="%Y%m%d", errors="coerce")
        invalid_dates = int(((raw_dates != "") & parsed.isna()).sum())
        if invalid_dates:
            conversion_errors["기준일자"] = invalid_dates
        frame["기준일자"] = parsed

    duplicate_count = int(frame.duplicated().sum())
    frame = frame.drop_duplicates().reset_index(drop=True)

    ordered = [name for name in EXPECTED_COLUMNS if name in frame.columns]
    ordered.extend(column for column in frame.columns if column not in ordered)
    frame = frame[ordered]
    if "기준일자" in frame.columns:
        sort_columns = ["기준일자"]
        if "종목명" in frame.columns:
            sort_columns.append("종목명")
        frame = frame.sort_values(sort_columns, kind="mergesort").reset_index(drop=True)

    missing_counts = {
        column: int(frame[column].isna().sum())
        for column in frame.columns
        if int(frame[column].isna().sum()) > 0
    }
    return {
        "dataframe": frame,
        "before_count": before_count,
        "after_count": len(frame),
        "duplicate_count": duplicate_count,
        "missing_counts": missing_counts,
        "conversion_errors": {name: count for name, count in conversion_errors.items() if count},
        "missing_columns": missing_columns,
        "extra_columns": unknown,
    }


def filter_frame(
    frame: pd.DataFrame,
    *,
    start_date: Optional[date] = None,
    end_date: Optional[date] = None,
    itms_nm: str = "",
    srtn_cd: str = "",
    mrkt_cls: str = "",
) -> pd.DataFrame:
    """이미 수집한 표를 조회 조건으로 한 번 더 좁힌다."""
    filtered = frame
    if "기준일자" in filtered.columns and start_date and end_date:
        start = pd.Timestamp(start_date)
        end = pd.Timestamp(end_date)
        dates = filtered["기준일자"]
        filtered = filtered[dates.notna() & (dates >= start) & (dates <= end)]
    if itms_nm.strip() and "종목명" in filtered.columns:
        filtered = filtered[filtered["종목명"].str.contains(itms_nm.strip(), na=False)]
    if srtn_cd.strip() and "단축코드" in filtered.columns:
        filtered = filtered[filtered["단축코드"].str.contains(srtn_cd.strip(), na=False)]
    if mrkt_cls.strip() and mrkt_cls.strip() != "전체" and "시장구분" in filtered.columns:
        filtered = filtered[filtered["시장구분"] == mrkt_cls.strip()]
    return filtered.reset_index(drop=True)


def summarize_statistics(frame: pd.DataFrame) -> pd.DataFrame:
    columns = [name for name in STAT_COLUMNS if name in frame.columns]
    if frame.empty or not columns:
        return pd.DataFrame()
    summary = frame[columns].describe().transpose().round(2)
    summary.index.name = "항목"
    return summary.reset_index()


def chart_frames(frame: pd.DataFrame) -> dict:
    """API가 제공한 종가·등락률·거래량·거래대금만 그래프로 쓴다."""
    charts: dict[str, Any] = {"mode": "empty"}
    if frame.empty or "종목명" not in frame.columns:
        return charts

    names = int(frame["종목명"].nunique()) if "종목명" in frame.columns else 0
    dates = int(frame["기준일자"].nunique()) if "기준일자" in frame.columns else 0

    if names <= 8 and dates >= 2 and "종가" in frame.columns:
        close = frame.pivot_table(index="기준일자", columns="종목명", values="종가", aggfunc="mean")
        charts["mode"] = "timeseries"
        charts["close"] = close.sort_index()
        if "거래량" in frame.columns:
            charts["volume"] = frame.pivot_table(
                index="기준일자", columns="종목명", values="거래량", aggfunc="sum"
            ).sort_index()
        return charts

    if "기준일자" in frame.columns and frame["기준일자"].notna().any():
        latest = frame["기준일자"].max()
        day = frame[frame["기준일자"] == latest].copy()
        charts["latest_date"] = latest
    else:
        day = frame.copy()
        charts["latest_date"] = None

    charts["mode"] = "cross_section"
    if "거래대금" in day.columns:
        ranked = day.dropna(subset=["거래대금"]).nlargest(15, "거래대금")
        charts["amount"] = ranked.set_index("종목명")[["거래대금"]]
    if "등락률" in day.columns:
        movers = day.dropna(subset=["등락률"]).copy()
        movers = movers.reindex(movers["등락률"].abs().sort_values(ascending=False).index).head(15)
        charts["change_rate"] = movers.set_index("종목명")[["등락률"]]
    return charts


def _clean_text(value: Any) -> str:
    if value is None or (isinstance(value, float) and pd.isna(value)):
        return ""
    return str(value).strip()


def _to_number(series: pd.Series) -> tuple[pd.Series, int]:
    text = series.map(_clean_text).str.replace(",", "", regex=False)
    present = text != ""
    converted = pd.to_numeric(text.where(present), errors="coerce")
    failed = int((present & converted.isna()).sum())
    return converted, failed


def _is_whole(series: pd.Series) -> bool:
    values = series.dropna()
    if values.empty:
        return True
    return bool((values % 1 == 0).all())


def _json_ready(value: Any) -> Any:
    if value is None or (isinstance(value, float) and pd.isna(value)):
        return None
    if pd.isna(value):
        return None
    if isinstance(value, (datetime, pd.Timestamp)):
        if pd.isna(value):
            return None
        return value.strftime("%Y-%m-%d")
    if hasattr(value, "item"):
        try:
            return value.item()
        except (ValueError, AttributeError):
            return str(value)
    return value


def build_fact_sheet(frame: pd.DataFrame, meta: dict, query: dict) -> str:
    """모델에 보낼 짧은 사실 요약. 원본 전체를 넣지 않는다."""
    lines = [
        "아래는 앱이 공공데이터(또는 샘플)에서 계산한 사실입니다.",
        "이 수치 밖에 있는 가격, 순위, 이유는 만들지 말고, 매수·매도 추천도 하지 마세요.",
        "",
        f"데이터 소스: {meta.get('service', meta.get('source', ''))}",
        f"조회 시작일: {query.get('start_date', '-')}",
        f"조회 종료일: {query.get('end_date', '-')}",
        f"종목명 조건: {query.get('itms_nm') or '전체'}",
        f"단축코드 조건: {query.get('srtn_cd') or '전체'}",
        f"시장구분 조건: {query.get('mrkt_cls') or '전체'}",
        f"페이지: {query.get('page_no', meta.get('page_no', '-'))}",
        f"페이지당 요청 건수: {query.get('num_of_rows', meta.get('num_of_rows', '-'))}",
        f"API totalCount: {meta.get('total_count', '-')}",
        f"이번 분석에 사용한 행 수: {len(frame)}",
        "등락률 단위: API가 준 값 그대로(보통 전일 대비 퍼센트 포인트)",
        "금액 단위: 원. 별도 지표(이동평균, RSI 등)는 계산하지 않았습니다.",
    ]

    if frame.empty:
        lines.append("분석할 행이 없습니다.")
        return "\n".join(lines)

    if "기준일자" in frame.columns and frame["기준일자"].notna().any():
        lines.append(
            "실제 데이터 일자: "
            f"{frame['기준일자'].min():%Y-%m-%d} ~ {frame['기준일자'].max():%Y-%m-%d}"
        )
    if "종목명" in frame.columns:
        names = sorted(frame["종목명"].dropna().unique().tolist())
        preview = ", ".join(names[:20])
        suffix = f" 외 {len(names) - 20}개" if len(names) > 20 else ""
        lines.append(f"종목 수: {len(names)}")
        lines.append(f"종목: {preview}{suffix}")
    if "시장구분" in frame.columns:
        counts = frame["시장구분"].value_counts(dropna=False).to_dict()
        lines.append(f"시장구분 건수: {counts}")

    lines.append("")
    lines.append("[기술통계: 건수, 평균, 최소, 최대]")
    for column in STAT_COLUMNS:
        if column not in frame.columns:
            continue
        values = frame[column].dropna()
        if values.empty:
            lines.append(f"- {column}: 값 없음")
            continue
        lines.append(
            f"- {column}: 건수 {int(values.count())}, 평균 {float(values.mean()):.4f}, "
            f"최소 {float(values.min()):.4f}, 최대 {float(values.max()):.4f}"
        )

    if (
        "종목명" in frame.columns
        and "종가" in frame.columns
        and "기준일자" in frame.columns
        and frame["종목명"].nunique() == 1
    ):
        ordered = frame.dropna(subset=["기준일자", "종가"]).sort_values("기준일자")
        if len(ordered) >= 2:
            first = ordered.iloc[0]
            last = ordered.iloc[-1]
            change = float(last["종가"]) - float(first["종가"])
            lines.append("")
            lines.append("[단일 종목 기간 집계]")
            lines.append(
                f"- 시작 {first['기준일자']:%Y-%m-%d} 종가 {int(first['종가'])}, "
                f"끝 {last['기준일자']:%Y-%m-%d} 종가 {int(last['종가'])}, "
                f"차이 {change:.0f} (끝 종가 - 시작 종가)"
            )

    lines.append("")
    lines.append("[등락률 상위 5행]")
    lines.extend(_extreme_lines(frame, largest=True))
    lines.append("[등락률 하위 5행]")
    lines.extend(_extreme_lines(frame, largest=False))
    lines.append("")
    lines.append("[표본 행 최대 8건]")
    show_columns = [name for name in ["기준일자", "종목명", "시장구분", "종가", "대비", "등락률", "거래량", "거래대금"] if name in frame.columns]
    sample = frame[show_columns].head(8)
    for record in sample.to_dict(orient="records"):
        rendered = {key: _json_ready(value) for key, value in record.items()}
        lines.append(f"- {rendered}")

    text = "\n".join(lines)
    if len(text) > 6000:
        text = text[:6000] + "\n(요약이 길어 이후 내용은 잘라 냈습니다.)"
    return text


def _extreme_lines(frame: pd.DataFrame, largest: bool) -> list[str]:
    if "등락률" not in frame.columns or frame["등락률"].dropna().empty:
        return ["- 등락률 값이 없습니다."]
    columns = [name for name in ["기준일자", "종목명", "종가", "등락률", "거래량"] if name in frame.columns]
    picked = frame.dropna(subset=["등락률"]).nlargest(5, "등락률") if largest else frame.dropna(subset=["등락률"]).nsmallest(5, "등락률")
    rows = []
    for record in picked[columns].to_dict(orient="records"):
        rendered = {key: _json_ready(value) for key, value in record.items()}
        rows.append(f"- {rendered}")
    return rows
