# 공공데이터 주식시세 분석

금융위원회 주식시세정보 API로 일별 시세를 조회하고, pandas로 정리한 뒤 OpenAI `gpt-4o-mini`가 그 통계를 설명하는 Streamlit 앱입니다. 투자 매수·매도 추천 기능은 없습니다.

## 사용하는 API

공공데이터포털에서 명세를 확인한 서비스만 호출합니다.

| 항목 | 내용 |
| --- | --- |
| 이름 | 금융위원회_주식시세정보 |
| 데이터 | [data.go.kr/data/15094808](https://www.data.go.kr/data/15094808/openapi.do) |
| 오퍼레이션 | 주식시세 `getStockPriceInfo` |
| 요청 | `GET https://apis.data.go.kr/1160100/service/GetStockSecuritiesInfoService/getStockPriceInfo` |
| 필수 파라미터 | `serviceKey`, `numOfRows`, `pageNo`, `resultType=json` |
| 이 앱이 쓰는 선택 파라미터 | `basDt`, `beginBasDt`, `endBasDt`, `likeItmsNm`, `likeSrtnCd`, `mrktCls` |

`endBasDt`는 기준일자가 검색값보다 **작은** 자료만 돌려줍니다. 화면에서 고른 종료일까지 포함하려고, 기간 조회일 때만 종료일 다음 날을 `endBasDt`로 보냅니다. 시작일과 종료일이 같으면 `basDt` 하루 조회입니다.

시세는 실시간이 아닙니다. 기준일 다음 영업일 오후 1시 이후에 반영됩니다. 응답 항목은 기준일자, 단축코드, ISIN코드, 종목명, 시장구분, 종가, 대비, 등락률, 시가, 고가, 저가, 거래량, 거래대금, 상장주식수, 시가총액입니다. API에 없는 보조지표는 만들지 않습니다.

## 환경 변수

인증키는 `c:\env\.env`에서만 읽습니다. 소스에 키를 적지 마세요.

```text
DATA_API_KEY=발급받은_API_인증키
OPENAI_API_KEY=발급받은_OpenAI_API_키
```

- `DATA_API_KEY`: 공공데이터포털 활용 신청 후 받는 일반 인증키. `%`가 들어 있는 인코딩 키도 앱이 한 번 디코딩한 뒤 요청합니다.
- `OPENAI_API_KEY`: OpenAI API 키. 모델명은 `gpt-4o-mini`로 고정되어 있습니다.
- 이 파일을 Git에 넣지 않도록 `.gitignore`에 `.env`를 넣어 두었습니다. 키 파일은 프로젝트 폴더 밖에 있습니다.

키가 없으면 화면이 설정 위치와 항목 이름을 안내합니다. 공공데이터 키가 아직 없어도 **샘플 JSON**으로 전처리, 통계, 그래프, AI 분석을 실행할 수 있습니다. 샘플 숫자는 실제 시세가 아닙니다.

## 설치와 실행

Python 3.10 이상이 필요합니다.

```powershell
cd public_finance_agent
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
streamlit run app.py
```

실행 정책 때문에 가상환경 활성화가 막히면 아래처럼 바로 실행할 수 있습니다.

```powershell
.\.venv\Scripts\python.exe -m streamlit run app.py
```

브라우저에서 `http://localhost:8501` 이 열립니다.

## 화면에서 하는 일

1. 상단에서 두 API 키가 설정됐는지만 확인합니다. 키 문자열은 표시하지 않습니다.
2. 소스, 기간, 종목명, 단축코드, 시장, 페이지, 조회 건수를 입력합니다.
3. **데이터 수집**으로 API 또는 샘플을 가져옵니다.
4. 원본 표, 전처리 표, 전후 건수, 중복·결측, 기술통계, 종가·거래량 또는 등락률·거래대금 그래프를 봅니다.
5. **API 응답 원본 보기**를 켜면 인증키를 가린 요청 파라미터와 응답 일부를 확인합니다.
6. **gpt-4o-mini 분석 실행**을 누르면 통계와 일부 행만 모델에 보내고 설명을 출력합니다.

조회 건수는 한 번에 최대 1000행입니다. 응답의 전체 건수가 더 크면 페이지 번호를 올려 이어서 조회합니다.

## 샘플로 확인하는 방법

데이터 소스를 **샘플 JSON**으로 바꾸고, 기간을 `2026-11-10` ~ `2026-11-14`로 맞춘 뒤 데이터 수집을 누릅니다. 샘플에는 중복 1건과 등락률 결측 1건이 들어 있어 전처리 메시지를 함께 볼 수 있습니다.

## 자주 생기는 문제

| 증상 | 확인 |
| --- | --- |
| 키 없음 | `c:\env\.env` 이름과 `DATA_API_KEY`, `OPENAI_API_KEY` 철자 |
| 결과 코드 03 또는 0건 | 주말·휴일 대신 영업일, 종목명 철자. 당일 시세는 다음 영업일 13시 이후 |
| 결과 코드 30 | 활용 신청한 서비스의 인증키인지, 따옴표나 공백이 붙지 않았는지 |
| JSON 파싱 실패 | Decoding 키를 쓰는지, 오류 본문이 XML인지 디버그에서 확인 |
| HTTP 오류 | 네트워크와 활용 승인 상태 |
| OpenAI 인증 오류 | `OPENAI_API_KEY`와 모델 사용 권한 |
| OpenAI 지연 | 분석 버튼을 다시 누름. 원본 전체는 보내지 않음 |

## 파일

| 파일 | 역할 |
| --- | --- |
| `app.py` | Streamlit 화면 |
| `api_client.py` | 공공데이터 호출, 오류 처리, 샘플 로드 |
| `data_processor.py` | 전처리, 필터, 기술통계, 모델용 요약 |
| `ai_analyzer.py` | `gpt-4o-mini` 호출 |
| `sample_data.json` | 키가 없을 때 쓰는 샘플 |
| `requirements.txt` | 라이브러리 |
| `.gitignore` | `.env`, 가상환경, 캐시 제외 |

## 데이터 이용

금융위원회 개방데이터는 공공누리 4유형(출처표시, 상업적 이용 금지, 변경 금지)입니다. 상업적 이용은 한국거래소 데이터 정책을 따라야 합니다. 이 앱의 설명은 학습용 정보 제공이며 투자 자문이 아닙니다.
