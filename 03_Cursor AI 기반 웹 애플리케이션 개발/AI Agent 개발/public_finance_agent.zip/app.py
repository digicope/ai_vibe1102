"""공공데이터 주식시세 조회와 GPT-4o-mini 설명 화면."""

from __future__ import annotations

import time
from datetime import date, timedelta

import pandas as pd
import streamlit as st

from ai_analyzer import MODEL_NAME, analyze_summary, openai_key_configured
from api_client import (
    ENV_PATH,
    SERVICE_NAME,
    ApiClientError,
    data_key_configured,
    env_file_exists,
    fetch_stock_prices,
    load_sample_records,
)
from data_processor import DataProcessingError, build_fact_sheet, chart_frames, filter_frame, preprocess, summarize_statistics

st.set_page_config(page_title="공공데이터 금융 분석", page_icon="📈", layout="wide")


def main() -> None:
    st.title("공공데이터 주식시세 분석")
    st.write(
        f"{SERVICE_NAME} API로 일별 시세를 수집하고, 표와 기술통계로 정리한 뒤 "
        f"{MODEL_NAME}가 그 범위 안에서 특징을 설명합니다. "
        "매수·매도 추천은 하지 않습니다."
    )

    render_connection_status()
    query, submitted = render_query_form()

    if submitted:
        collect(query)

    error = st.session_state.get("error")
    if error:
        st.error(error["message"])
        if error.get("hint"):
            st.info(error["hint"].replace("\\", "/"))
        if error.get("debug"):
            with st.expander("오류 응답 디버그 (인증키는 가림)"):
                st.json(error["debug"])

    result = st.session_state.get("result")
    if not result:
        st.caption("조회 조건을 고른 뒤 데이터 수집을 누르면 표, 통계, AI 분석이 이 아래에 나타납니다.")
        return

    render_result(result)


def render_connection_status() -> None:
    data_ok = data_key_configured()
    openai_ok = openai_key_configured()
    file_label = str(ENV_PATH) if env_file_exists() else f"{ENV_PATH} 파일 없음"

    left, right = st.columns(2)
    left.metric("공공데이터 API", "키 설정됨" if data_ok else "키 없음")
    right.metric("OpenAI GPT-4o-mini", "키 설정됨" if openai_ok else "키 없음")
    st.text(f"환경 변수 파일: {file_label}. 키 값은 화면에 표시하지 않습니다.")

    if not data_ok or not openai_ok:
        missing = []
        if not data_ok:
            missing.append("DATA_API_KEY=발급받은_API_인증키")
        if not openai_ok:
            missing.append("OPENAI_API_KEY=발급받은_OpenAI_API_키")
        st.warning(
            "c:/env/.env 에 아래 항목을 저장한 뒤 앱을 다시 실행하세요.\n\n"
            + "\n".join(missing)
            + "\n\n공공데이터 키가 없으면 샘플 JSON으로 전처리와 화면을 확인할 수 있습니다. "
            "코드에는 인증키를 적지 않습니다."
        )


def render_query_form() -> tuple[dict, bool]:
    default_day = last_business_day()
    st.subheader("조회 조건")
    with st.form("collect_form", border=True):
        source = st.radio(
            "데이터 소스",
            options=["api", "sample"],
            format_func=lambda value: "공공데이터 API" if value == "api" else "샘플 JSON",
            horizontal=True,
        )
        col1, col2, col3, col4 = st.columns(4)
        start_date = col1.date_input("시작일", value=default_day, max_value=date.today())
        end_date = col2.date_input("종료일", value=default_day, max_value=date.today())
        itms_nm = col3.text_input("종목명 (포함)", placeholder="예: 삼성")
        srtn_cd = col4.text_input("단축코드 (포함)", placeholder="예: 005930")

        col5, col6, col7 = st.columns(3)
        mrkt_cls = col5.selectbox("시장구분", ["전체", "KOSPI", "KOSDAQ", "KONEX"])
        page_no = col6.number_input("페이지 번호", min_value=1, max_value=9999, value=1, step=1)
        num_of_rows = col7.number_input("조회 건수", min_value=1, max_value=1000, value=100, step=10)
        submitted = st.form_submit_button("데이터 수집", type="primary")

    st.checkbox("API 응답 원본 보기", key="show_debug")
    st.caption(
        "시작일과 종료일이 같으면 basDt(해당 일자)로 조회합니다. "
        "기간 조회는 beginBasDt 이상, endBasDt 미만 규칙을 맞춰 종료일까지 포함합니다. "
        "자료는 기준일 다음 영업일 13시 이후에 갱신됩니다. "
        "샘플은 2026-11-10부터 2026-11-14까지이며 실제 시세가 아닙니다."
    )
    return {
        "source": source,
        "start_date": start_date,
        "end_date": end_date,
        "itms_nm": itms_nm.strip(),
        "srtn_cd": srtn_cd.strip(),
        "mrkt_cls": mrkt_cls,
        "page_no": int(page_no),
        "num_of_rows": int(num_of_rows),
    }, submitted


def collect(query: dict) -> None:
    st.session_state["analysis"] = None
    st.session_state["error"] = None
    if query["start_date"] > query["end_date"]:
        st.session_state["error"] = {
            "message": "시작일이 종료일보다 늦습니다.",
            "hint": "조회 기간을 다시 선택하세요.",
        }
        return

    started = time.perf_counter()
    try:
        with st.spinner("데이터를 수집하는 중입니다."):
            if query["source"] == "sample":
                payload = load_sample_records()
            else:
                payload = fetch_stock_prices(
                    page_no=query["page_no"],
                    num_of_rows=query["num_of_rows"],
                    start_date=query["start_date"],
                    end_date=query["end_date"],
                    itms_nm=query["itms_nm"],
                    srtn_cd=query["srtn_cd"],
                    mrkt_cls=query["mrkt_cls"],
                )
    except ApiClientError as exc:
        st.session_state["result"] = None
        st.session_state["error"] = {
            "message": str(exc),
            "hint": exc.hint,
            "debug": exc.debug,
        }
        return

    st.session_state["result"] = {
        "records": payload["records"],
        "meta": payload["meta"],
        "debug": payload["debug"],
        "query": {**query, "start_date": str(query["start_date"]), "end_date": str(query["end_date"])},
        "elapsed": time.perf_counter() - started,
    }


def render_result(result: dict) -> None:
    query = result["query"]
    meta = result["meta"]
    if meta.get("source") == "sample":
        st.warning("지금 보이는 숫자는 샘플 JSON입니다. 실제 시장 시세가 아닙니다.")

    st.success(
        f"수집이 끝났습니다. 적용 기간 {query['start_date']} ~ {query['end_date']}, "
        f"종목명 '{query['itms_nm'] or '전체'}', 시장 {query['mrkt_cls']}. "
        f"받은 행 {meta.get('received_count', len(result['records']))}건, "
        f"소요 {result.get('elapsed', 0):.1f}초."
    )

    try:
        processed = preprocess(result["records"])
    except DataProcessingError as exc:
        st.error(str(exc))
        if exc.hint:
            st.info(exc.hint)
        render_debug(result)
        return

    frame = filter_frame(
        processed["dataframe"],
        start_date=date.fromisoformat(query["start_date"]),
        end_date=date.fromisoformat(query["end_date"]),
        itms_nm=query["itms_nm"],
        srtn_cd=query["srtn_cd"],
        mrkt_cls=query["mrkt_cls"],
    )
    if frame.empty:
        hint = "기준일자를 영업일로 바꾸거나 종목명·시장 조건을 완화해 다시 수집하세요."
        if meta.get("source") == "sample":
            hint = (
                "샘플에는 2026-11-10 ~ 2026-11-14 자료만 있습니다. "
                "기간을 그 구간으로 바꾸거나 종목명 조건을 지워 보세요."
            )
        st.info("조건에 맞는 행이 없습니다. " + hint)

    render_counts(processed, meta, len(frame))
    render_quality(processed)
    render_tables(result["records"], frame)
    render_statistics(frame)
    render_debug(result)
    render_analysis(frame, meta, query)


def render_counts(processed: dict, meta: dict, filtered_count: int) -> None:
    st.subheader("수집 건수")
    first, second, third, fourth = st.columns(4)
    first.metric("API 전체 건수", _metric_value(meta.get("total_count")))
    second.metric("받은 원본 건수", processed["before_count"])
    third.metric("전처리 후 건수", processed["after_count"])
    fourth.metric("화면 표시 건수", filtered_count)
    if meta.get("total_count") and meta.get("received_count") is not None:
        if meta["total_count"] > meta["received_count"]:
            st.caption("전체 건수가 이번 페이지보다 많습니다. 페이지 번호나 조회 건수를 바꿔 이어서 볼 수 있습니다.")


def render_quality(processed: dict) -> None:
    messages = [f"중복으로 제거한 행: {processed['duplicate_count']}건"]
    if processed["missing_columns"]:
        messages.append("응답에 없던 컬럼: " + ", ".join(processed["missing_columns"]))
    if processed["conversion_errors"]:
        detail = ", ".join(f"{name} {count}건" for name, count in processed["conversion_errors"].items())
        messages.append("숫자·날짜로 바꾸지 못한 값: " + detail)
    if processed["missing_counts"]:
        detail = ", ".join(f"{name} {count}건" for name, count in processed["missing_counts"].items())
        messages.append("결측: " + detail)
    else:
        messages.append("전처리 후 결측은 없습니다.")
    st.info("\n\n".join(messages))


def render_tables(records: list[dict], frame: pd.DataFrame) -> None:
    raw_tab, processed_tab = st.tabs(["원본 데이터", "전처리 데이터"])
    with raw_tab:
        st.dataframe(pd.DataFrame(records), width="stretch", hide_index=True)
    with processed_tab:
        st.dataframe(_display_frame(frame), width="stretch", hide_index=True)


def render_statistics(frame: pd.DataFrame) -> None:
    st.subheader("데이터 통계와 시각화")
    if frame.empty:
        st.info("표시할 행이 없어 통계와 그래프를 그리지 않았습니다.")
        return

    summary = summarize_statistics(frame)
    if summary.empty:
        st.info("통계를 낼 숫자 컬럼이 없습니다.")
    else:
        st.dataframe(summary, width="stretch", hide_index=True)

    charts = chart_frames(frame)
    if charts.get("mode") == "timeseries":
        st.write("종가")
        st.line_chart(charts["close"], width="stretch")
        if "volume" in charts:
            st.write("거래량")
            st.line_chart(charts["volume"], width="stretch")
        st.caption("같은 날짜·종목이 여러 번 있으면 종가는 평균, 거래량은 합계로 그립니다. 새 지표는 만들지 않습니다.")
        return

    if charts.get("mode") == "cross_section":
        latest = charts.get("latest_date")
        if latest is not None and not pd.isna(latest):
            st.caption(f"그래프 기준일: {pd.Timestamp(latest):%Y-%m-%d} (이 페이지에서 거래대금 또는 등락률 절대값이 큰 15종목)")
        left, right = st.columns(2)
        if "change_rate" in charts and not charts["change_rate"].empty:
            left.write("등락률")
            left.bar_chart(charts["change_rate"], width="stretch")
        if "amount" in charts and not charts["amount"].empty:
            right.write("거래대금")
            right.bar_chart(charts["amount"], width="stretch")


def render_debug(result: dict) -> None:
    if not st.session_state.get("show_debug"):
        return
    st.subheader("응답 원본 디버그")
    st.caption("serviceKey는 파라미터에서 *** 로 바꿨습니다.")
    st.json(result["debug"])


def render_analysis(frame: pd.DataFrame, meta: dict, query: dict) -> None:
    st.subheader("OpenAI GPT-4o-mini 분석")
    st.caption("모델에는 전체 행 대신 기술통계, 등락률 상·하위 5건, 표본 8건만 전달합니다.")
    if frame.empty:
        st.info("분석할 데이터가 없습니다.")
        return

    if st.button(f"{MODEL_NAME} 분석 실행"):
        summary = build_fact_sheet(frame, meta, query)
        st.session_state["fact_sheet"] = summary
        started = time.perf_counter()
        try:
            with st.spinner("GPT-4o-mini가 요약을 읽고 있습니다."):
                analysis = analyze_summary(summary)
            st.session_state["analysis"] = analysis
            st.session_state["analysis_elapsed"] = time.perf_counter() - started
            st.session_state["analysis_error"] = None
        except Exception as exc:
            if exc.__class__.__name__ in {"RerunException", "StopException"}:
                raise
            hint = getattr(exc, "hint", "")
            st.session_state["analysis"] = None
            st.session_state["analysis_error"] = {"message": str(exc), "hint": hint}

    analysis_error = st.session_state.get("analysis_error")
    if analysis_error:
        st.error(analysis_error["message"])
        if analysis_error.get("hint"):
            st.info(analysis_error["hint"].replace("\\", "/"))

    analysis = st.session_state.get("analysis")
    if analysis:
        elapsed = st.session_state.get("analysis_elapsed")
        if elapsed is not None:
            st.caption(f"분석 응답 시간: {elapsed:.1f}초")
        st.write(analysis)

    fact_sheet = st.session_state.get("fact_sheet")
    if fact_sheet:
        with st.expander("모델에 전달한 요약"):
            st.code(fact_sheet, language="text")


def _display_frame(frame: pd.DataFrame) -> pd.DataFrame:
    display = frame.copy()
    if "기준일자" in display.columns:
        display["기준일자"] = display["기준일자"].dt.strftime("%Y-%m-%d")
    return display


def _metric_value(value: object) -> str:
    if value is None:
        return "-"
    return f"{int(value):,}"


def last_business_day(today: date | None = None) -> date:
    """자료 반영 시차를 고려해 오늘 이전의 최근 평일을 기본값으로 쓴다."""
    day = (today or date.today()) - timedelta(days=1)
    while day.weekday() >= 5:
        day -= timedelta(days=1)
    return day


if __name__ == "__main__":
    main()
