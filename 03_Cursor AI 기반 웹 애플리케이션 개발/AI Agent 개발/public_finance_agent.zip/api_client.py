"""금융위원회 주식시세정보 API 호출.

확인한 명세 (공공데이터포털 15094808):
- 서비스: GetStockSecuritiesInfoService
- 오퍼레이션: getStockPriceInfo (주식시세)
- 메서드: GET
- 필수 파라미터: serviceKey, numOfRows, pageNo, resultType
- 선택 파라미터: basDt, beginBasDt, endBasDt, likeItmsNm, likeSrtnCd, mrktCls
- endBasDt는 '기준일자 < 검색값' (미만) 조건이다.
"""

from __future__ import annotations

import json
import os
from datetime import date, timedelta
from pathlib import Path
from typing import Any, Optional
from urllib.parse import quote, unquote

import requests
from dotenv import load_dotenv

ENV_PATH = Path(r"c:\env\.env")
API_URL = (
    "https://apis.data.go.kr/1160100/service/"
    "GetStockSecuritiesInfoService/getStockPriceInfo"
)
SERVICE_NAME = "금융위원회_주식시세정보"
DATA_PORTAL_URL = "https://www.data.go.kr/data/15094808/openapi.do"
SAMPLE_PATH = Path(__file__).resolve().parent / "sample_data.json"

RESULT_HINTS = {
    "01": "활용 신청 상태와 서비스 주소를 확인하세요.",
    "02": "제공 기관 데이터베이스 오류입니다. 잠시 후 다시 시도하세요.",
    "03": "조건에 맞는 데이터가 없습니다. 영업일 기준일자와 종목명을 확인하세요.",
    "04": "API 서버 HTTP 오류입니다. 잠시 후 다시 시도하세요.",
    "10": "잘못된 요청 파라미터입니다. 날짜는 YYYYMMDD, 시장구분은 KOSPI/KOSDAQ/KONEX 인지 확인하세요.",
    "11": "필수 파라미터가 빠졌습니다. serviceKey, numOfRows, pageNo, resultType을 확인하세요.",
    "12": "해당 오퍼레이션이 개방되어 있는지 활용 신청 목록을 확인하세요.",
    "20": "서비스 접근이 거부되었습니다. 활용 승인 여부를 확인하세요.",
    "22": "호출 허용량을 초과했습니다. 잠시 후 다시 시도하세요.",
    "30": "등록되지 않은 인증키입니다. 공공데이터포털의 일반 인증키를 c:\\env\\.env에 넣으세요.",
    "31": "인증키 사용 기한이 만료되었습니다. 공공데이터포털에서 키를 갱신하세요.",
    "32": "등록되지 않은 IP입니다. 활용 신청의 IP 제한을 확인하세요.",
}


class ApiClientError(Exception):
    """API 호출 실패. 화면에는 message와 hint만 보여 준다."""

    def __init__(self, message: str, hint: str = "", debug: Optional[dict] = None):
        super().__init__(message)
        self.hint = hint
        self.debug = debug or {}


def load_environment() -> None:
    """c:\\env\\.env의 환경 변수를 읽는다. 이미 설정된 값은 덮어쓰지 않는다."""
    if ENV_PATH.is_file():
        load_dotenv(ENV_PATH)


def _clean_secret(value: Optional[str]) -> str:
    if not value:
        return ""
    return value.strip().strip('"').strip("'")


def get_data_api_key() -> str:
    load_environment()
    key = _clean_secret(os.getenv("DATA_API_KEY"))
    if "%" in key:
        key = unquote(key)
    return key


def data_key_configured() -> bool:
    return bool(get_data_api_key())


def env_file_exists() -> bool:
    return ENV_PATH.is_file()


def redact(text: str, secret: str = "") -> str:
    """오류 문구에 인증키가 섞여 나가지 않도록 가린다."""
    if not text:
        return ""
    key = secret or get_data_api_key()
    if not key:
        return text
    hidden = text.replace(key, "***")
    encoded = quote(key, safe="")
    if encoded:
        hidden = hidden.replace(encoded, "***")
    return hidden


def load_sample_payload() -> dict:
    if not SAMPLE_PATH.is_file():
        raise ApiClientError(
            "샘플 JSON 파일을 찾을 수 없습니다.",
            f"다음 경로에 sample_data.json이 있는지 확인하세요: {SAMPLE_PATH}",
        )
    try:
        return json.loads(SAMPLE_PATH.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise ApiClientError(
            "샘플 JSON을 해석하지 못했습니다.",
            str(exc),
        ) from exc


def extract_records(payload: dict) -> tuple[list[dict], dict]:
    """응답 JSON에서 item 목록과 페이징 정보를 꺼낸다."""
    if not isinstance(payload, dict):
        raise ApiClientError(
            "응답이 JSON 객체가 아닙니다.",
            "resultType=json 으로 요청했는지 확인하세요.",
        )

    response = payload.get("response")
    if not isinstance(response, dict):
        raise ApiClientError(
            "응답에 response 객체가 없습니다.",
            "주식시세 API 응답 구조가 맞는지 원본 디버그를 확인하세요.",
            debug={"top_level_keys": list(payload.keys())},
        )

    header = response.get("header") or {}
    body = response.get("body") or {}
    if not isinstance(header, dict) or not isinstance(body, dict):
        raise ApiClientError("응답 헤더 또는 본문 형식이 예상과 다릅니다.")

    code = str(header.get("resultCode", "")).strip()
    message = str(header.get("resultMsg", "")).strip()
    if code not in ("00", "0"):
        raise ApiClientError(
            f"API 결과 코드 {code or '-'}: {message or '메시지가 없습니다.'}",
            RESULT_HINTS.get(code, "공공데이터포털의 오류 코드를 확인하고 조회 조건을 바꿔 다시 시도하세요."),
            debug={"header": header},
        )

    total_count = _to_int(body.get("totalCount"))
    page_no = _to_int(body.get("pageNo"))
    num_of_rows = _to_int(body.get("numOfRows"))
    records = _items_to_list(body.get("items"))
    meta = {
        "result_code": code,
        "result_message": message,
        "total_count": total_count,
        "page_no": page_no,
        "num_of_rows": num_of_rows,
        "received_count": len(records),
    }
    return records, meta


def _items_to_list(items: Any) -> list[dict]:
    if items in (None, "", {}):
        return []
    if not isinstance(items, dict):
        raise ApiClientError(
            "items 형식을 해석할 수 없습니다.",
            "원본 응답 디버그를 확인해 주세요.",
        )
    item = items.get("item")
    if item in (None, "", []):
        return []
    if isinstance(item, dict):
        return [item]
    if isinstance(item, list):
        return [row for row in item if isinstance(row, dict)]
    raise ApiClientError("item 형식이 객체도 배열도 아닙니다.")


def _to_int(value: Any) -> Optional[int]:
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


def fetch_stock_prices(
    *,
    page_no: int,
    num_of_rows: int,
    start_date: date,
    end_date: date,
    itms_nm: str = "",
    srtn_cd: str = "",
    mrkt_cls: str = "",
    timeout: float = 30.0,
) -> dict:
    """주식시세 API를 호출하고 레코드, 메타, 디버그 정보를 반환한다."""
    key = get_data_api_key()
    if not key:
        raise ApiClientError(
            "공공데이터 인증키(DATA_API_KEY)가 없습니다.",
            _missing_key_hint(),
        )

    if page_no < 1:
        raise ApiClientError("페이지 번호는 1 이상이어야 합니다.")
    if not 1 <= num_of_rows <= 1000:
        raise ApiClientError("한 페이지 조회 건수는 1부터 1000까지 설정할 수 있습니다.")
    if start_date > end_date:
        raise ApiClientError("시작일이 종료일보다 늦습니다.", "조회 기간을 다시 선택하세요.")

    params: dict[str, Any] = {
        "serviceKey": key,
        "numOfRows": num_of_rows,
        "pageNo": page_no,
        "resultType": "json",
    }
    if start_date == end_date:
        params["basDt"] = start_date.strftime("%Y%m%d")
    else:
        params["beginBasDt"] = start_date.strftime("%Y%m%d")
        params["endBasDt"] = (end_date + timedelta(days=1)).strftime("%Y%m%d")

    if itms_nm.strip():
        params["likeItmsNm"] = itms_nm.strip()
    if srtn_cd.strip():
        params["likeSrtnCd"] = srtn_cd.strip()
    if mrkt_cls.strip() and mrkt_cls.strip() != "전체":
        params["mrktCls"] = mrkt_cls.strip()

    safe_params = {name: ("***" if name == "serviceKey" else value) for name, value in params.items()}
    try:
        response = requests.get(API_URL, params=params, timeout=timeout)
    except requests.Timeout as exc:
        raise ApiClientError(
            "API 응답 대기 시간이 초과되었습니다.",
            "네트워크 상태를 확인하거나 조회 건수를 줄인 뒤 다시 시도하세요.",
            debug={"url": API_URL, "params": safe_params, "error": redact(str(exc), key)},
        ) from exc
    except requests.RequestException as exc:
        raise ApiClientError(
            "API 서버에 연결하지 못했습니다.",
            "인터넷 연결을 확인한 뒤 다시 시도하세요. 샘플 데이터로 화면 기능은 먼저 확인할 수 있습니다.",
            debug={"url": API_URL, "params": safe_params, "error": redact(str(exc), key)},
        ) from exc

    preview = redact(response.text[:1500], key)
    debug = {
        "url": API_URL,
        "params": safe_params,
        "status_code": response.status_code,
        "content_type": response.headers.get("Content-Type", ""),
    }
    if response.status_code != 200:
        debug["body_preview"] = preview
        raise ApiClientError(
            f"HTTP 상태 코드 {response.status_code} 로 응답했습니다.",
            "인증키, 활용 승인, 요청 주소를 확인하세요. 원본 미리보기에 인증키는 표시하지 않습니다.",
            debug=debug,
        )

    try:
        payload = response.json()
    except ValueError as exc:
        debug["body_preview"] = preview
        raise ApiClientError(
            "JSON으로 해석할 수 없는 응답입니다.",
            "인증키 오류일 때 XML이 반환되는 경우가 있습니다. 일반 인증키(Decoding)와 resultType=json을 확인하세요.",
            debug=debug,
        ) from exc

    try:
        records, meta = extract_records(payload)
    except ApiClientError as exc:
        exc.debug = {**debug, "header": (exc.debug or {}).get("header"), "body_preview": _trim_payload(payload)}
        raise

    debug["body"] = _trim_payload(payload)
    meta["source"] = "api"
    meta["service"] = SERVICE_NAME
    return {"records": records, "meta": meta, "debug": debug}


def load_sample_records() -> dict:
    payload = load_sample_payload()
    records, meta = extract_records(payload)
    meta["source"] = "sample"
    meta["service"] = "샘플 JSON (실제 시세 아님)"
    notice = payload.get("_notice", "")
    debug = {
        "url": str(SAMPLE_PATH),
        "params": {"source": "sample_data.json"},
        "status_code": 200,
        "body": _trim_payload(payload),
        "notice": notice,
    }
    return {"records": records, "meta": meta, "debug": debug}


def _trim_payload(payload: dict, limit: int = 20) -> dict:
    """디버그 창에 실을 때 item은 일부만 남겨 화면이 멈추지 않게 한다."""
    try:
        cloned = json.loads(json.dumps(payload, ensure_ascii=False))
    except (TypeError, ValueError):
        return {"note": "원본 JSON을 복제하지 못했습니다."}
    response = cloned.get("response")
    if not isinstance(response, dict):
        return cloned
    body = response.get("body")
    if not isinstance(body, dict):
        return cloned
    items = body.get("items")
    if not isinstance(items, dict):
        return cloned
    item = items.get("item")
    if isinstance(item, list) and len(item) > limit:
        items["item"] = item[:limit]
        items["_truncated"] = f"{limit}건만 표시합니다. 전체 {len(item)}건은 아래 표에서 확인하세요."
    return cloned


def _missing_key_hint() -> str:
    location = str(ENV_PATH) if env_file_exists() else f"{ENV_PATH} (파일이 없습니다)"
    return (
        "c:\\env\\.env 파일에 인증키를 넣은 뒤 앱을 다시 실행하세요.\n"
        f"확인 위치: {location}\n"
        "DATA_API_KEY=발급받은_API_인증키\n"
        f"발급 페이지: {DATA_PORTAL_URL}\n"
        "소스 코드에는 키를 적지 않습니다. 키가 없으면 샘플 JSON으로 조회할 수 있습니다."
    )
