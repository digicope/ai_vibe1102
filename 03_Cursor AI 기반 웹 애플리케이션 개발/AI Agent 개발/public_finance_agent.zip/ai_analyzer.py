"""OpenAI GPT-4o-mini로 주식시세 요약을 해석한다."""

from __future__ import annotations

import os
from typing import Optional

from openai import APIConnectionError, APITimeoutError, AuthenticationError, OpenAI, RateLimitError

from api_client import ENV_PATH, load_environment

MODEL_NAME = "gpt-4o-mini"
SYSTEM_PROMPT = (
    "너는 금융 데이터를 사실대로 설명하는 분석 도우미이다. "
    "데이터에 없는 수치를 만들지 마라. "
    "투자 매수·매도 추천을 하지 말고, 제공된 통계와 표본의 범위 안에서만 변화와 패턴을 설명하라. "
    "분석에 사용한 데이터의 범위와 기준을 밝혀라. "
    "자료에 없는 원인(뉴스, 실적, 수급)은 추측하지 마라."
)


class AiAnalyzerError(Exception):
    def __init__(self, message: str, hint: str = ""):
        super().__init__(message)
        self.hint = hint


def _clean_secret(value: Optional[str]) -> str:
    if not value:
        return ""
    return value.strip().strip('"').strip("'")


def get_openai_api_key() -> str:
    load_environment()
    return _clean_secret(os.getenv("OPENAI_API_KEY"))


def openai_key_configured() -> bool:
    return bool(get_openai_api_key())


def analyze_summary(summary_text: str) -> str:
    """통계 요약만 모델에 보내고 설명 문단을 받는다."""
    if not summary_text.strip():
        raise AiAnalyzerError("분석에 전달할 요약이 비어 있습니다.", "먼저 데이터를 수집하세요.")

    key = get_openai_api_key()
    if not key:
        raise AiAnalyzerError(
            "OpenAI 인증키(OPENAI_API_KEY)가 없습니다.",
            "c:/env/.env 에 OPENAI_API_KEY=발급받은_OpenAI_API_키 를 저장한 뒤 앱을 다시 실행하세요.\n"
            f"확인 위치: {ENV_PATH}",
        )

    client = OpenAI(api_key=key, timeout=60.0, max_retries=1)
    try:
        response = client.chat.completions.create(
            model=MODEL_NAME,
            temperature=0.2,
            messages=[
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": summary_text},
            ],
        )
    except AuthenticationError as exc:
        raise AiAnalyzerError(
            "OpenAI 인증에 실패했습니다.",
            "OPENAI_API_KEY가 올바른지 확인하세요. 키 값은 화면에 표시하지 않습니다.",
        ) from exc
    except RateLimitError as exc:
        raise AiAnalyzerError(
            "OpenAI 호출 한도에 걸렸거나 결제가 필요합니다.",
            "잠시 후 다시 시도하거나 계정 한도를 확인하세요.",
        ) from exc
    except APITimeoutError as exc:
        raise AiAnalyzerError(
            "OpenAI 응답이 지연되어 요청을 중단했습니다.",
            "네트워크 상태를 확인한 뒤 분석 버튼을 다시 누르세요.",
        ) from exc
    except APIConnectionError as exc:
        raise AiAnalyzerError(
            "OpenAI 서버에 연결하지 못했습니다.",
            "인터넷 연결을 확인한 뒤 다시 시도하세요.",
        ) from exc
    except Exception as exc:
        raise AiAnalyzerError(
            "OpenAI 분석 중 오류가 발생했습니다.",
            _safe_error(str(exc), key),
        ) from exc

    choices = getattr(response, "choices", None) or []
    if not choices or not choices[0].message or not choices[0].message.content:
        raise AiAnalyzerError(
            "모델 응답이 비어 있습니다.",
            "잠시 후 다시 실행하세요.",
        )
    return choices[0].message.content.strip()


def _safe_error(message: str, secret: str) -> str:
    if secret and secret in message:
        return message.replace(secret, "***")
    return message[:500]
