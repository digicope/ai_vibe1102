# PDF 지능형 검색 Agent 시스템

여러 PDF 문서를 자동으로 로딩하고, LangChain을 사용하여 벡터스토어를 생성한 뒤, 주제별로 자동 분류하여 지능형 검색 및 질의응답을 제공하는 시스템입니다.

## 📋 프로젝트 개요

이 프로젝트는 다음과 같은 기능을 제공합니다:

- **자동 PDF 로딩**: `pdf_data/` 폴더의 모든 PDF 파일을 자동으로 로드
- **벡터스토어 생성**: LangChain과 FAISS를 사용한 벡터 임베딩 및 저장
- **주제 자동 분류**: PDF 내용을 분석하여 주제별로 자동 분류
- **지능형 검색**: LangChain v1.0의 `create_agent()`를 사용한 Agent 기반 검색
- **Streamlit UI**: 사용자 친화적인 웹 인터페이스

## 📁 프로젝트 구조

```
AI_Agent_PDF_Search_Project/
 ├── pdf_data/                    # PDF 데이터 파일 폴더
 ├── vector_store/                # 생성된 벡터스토어 저장 폴더 (자동 생성)
 ├── app.py                        # Streamlit UI 메인 파일
 ├── agent.py                      # LangChain create_agent 기반 검색 Agent
 ├── pdf_loader.py                 # LangChain PDF 로더 모듈
 ├── vector_store_manager.py       # 벡터스토어 생성/저장/불러오기
 ├── topic_classifier.py           # 임베딩 기반 주제 자동 생성/매핑
 ├── topic_classifier.pkl          # 저장된 주제 분류기 (자동 생성)
 ├── requirements.txt              # 필요한 Python 패키지 목록
 └── README.md                     # 프로젝트 설명서
```

## 🚀 설치 및 실행

### 1. 필수 요구사항

- Python 3.8 이상
- OpenAI API 키 (`.env` 파일에 설정 필요)

### 2. 패키지 설치

```bash
pip install -r requirements.txt
```

### 3. 환경 변수 설정

`C:/env/.env` 파일을 생성하고 다음 내용을 추가하세요:

```env
OPENAI_API_KEY=your_openai_api_key_here
```

**중요**: 환경 변수 파일은 반드시 `C:/env/.env` 경로에 있어야 합니다.

### 4. PDF 파일 준비

`pdf_data/` 폴더에 검색할 PDF 파일들을 넣어주세요.

### 5. 실행

```bash
C:\Users\storm\anaconda3\python.exe -m streamlit run app.py
```

또는 일반 Python으로:

```bash
streamlit run app.py
```

## 📊 PDF 처리 파이프라인

### 1. PDF 로딩 (`pdf_loader.py`)

- **LangChain PyPDFLoader** 사용
- `pdf_data/` 폴더의 모든 PDF 파일 자동 로드
- 각 문서에 파일명 메타데이터 추가

### 2. 문서 분할

- **RecursiveCharacterTextSplitter** 사용
- 기본 설정: `chunk_size=1000`, `chunk_overlap=200`
- 문서를 검색 가능한 청크로 분할

### 3. 벡터스토어 생성 (`vector_store_manager.py`)

- **FAISS** 벡터스토어 사용
- **OpenAI Embeddings** (text-embedding-3-small) 사용
- 첫 실행 시: 벡터스토어 생성 후 `vector_store/` 폴더에 저장
- 다음 실행 시: 기존 벡터스토어 자동 로드

### 4. 주제 분류 (`topic_classifier.py`)

주제 분류 과정:

1. **키워드 추출**: 각 문서에서 대표 키워드 5-7개 추출 (GPT-4o-mini 사용)
2. **임베딩 생성**: 키워드를 임베딩으로 변환
3. **클러스터링**: 유사도 기반으로 문서 그룹화
4. **주제명 생성**: 각 그룹에 대해 주제명 자동 생성 (GPT-4o-mini 사용)
5. **저장**: 주제 분류 결과를 `topic_classifier.pkl`에 저장

## 🤖 Agent 시스템

### LangChain v1.0 create_agent() 사용

이 프로젝트는 LangChain v1.0의 최신 `create_agent()` API를 사용합니다:

```python
from langchain.agents import create_agent

agent = create_agent(
    model="gpt-4o-mini",
    tools=[list_topics, get_topic_docs, search_vectorstore, summarize_docs],
    system_prompt="너는 PDF 통합 지능형 검색 Agent이다."
)

result = agent.invoke({
    "messages": [
        {"role": "user", "content": "기후 변화가 에너지 정책에 미치는 영향은?"}
    ]
})

answer = result["messages"][-1].content
```

### Agent 도구 (Tools)

Agent는 다음 4개의 도구를 사용합니다:

1. **`list_topics()`**: 현재 자동 생성된 주제 목록 반환
2. **`get_topic_docs(topic)`**: 특정 주제에 속한 문서 파일명 리스트 반환
3. **`search_vectorstore(query, topic, k)`**: 벡터스토어에서 유사도 검색 수행
4. **`summarize_docs(doc_contents)`**: 검색된 문서 청크들을 통합 요약

### Agent 작업 흐름

1. 사용자 질문 수신
2. `list_topics`로 주제 목록 확인
3. 질문 내용 분석하여 가장 관련 있는 주제 판단
4. 해당 주제로 `search_vectorstore` 호출
5. 검색 결과를 `summarize_docs`로 요약
6. 최종 답변 반환

## 🖥️ Streamlit UI 기능

### 1. 주제 목록 자동 출력

- 시스템 초기화 시 자동으로 주제 목록 생성
- 주제별 문서 개수 표시

### 2. 주제 선택

- 드롭다운 메뉴에서 주제 선택 가능
- 선택한 주제의 문서 목록 자동 표시

### 3. 질의응답

- 사용자가 질문 입력
- Agent가 자동으로 관련 주제 판단 및 검색
- 검색 결과 요약 및 답변 제공

### 4. 시스템 초기화

- 사이드바에서 시스템 초기화 버튼 제공
- 첫 실행 시 자동 초기화

## 💾 벡터스토어 저장/재사용

### 저장 위치

- 벡터스토어: `vector_store/` 폴더
- 주제 분류기: `topic_classifier.pkl` 파일

### 재사용 로직

1. **첫 실행 시**:
   - PDF 로드 → 벡터스토어 생성 → 주제 분류 → 저장

2. **다음 실행 시**:
   - 저장된 벡터스토어 확인
   - 존재하면 자동 로드
   - 주제 분류기도 자동 로드

### 수동 재생성

- `vector_store/` 폴더 삭제 후 재실행
- `topic_classifier.pkl` 파일 삭제 후 재실행

## ⚠️ Windows 폴더 경로 주의사항

### 환경 변수 파일 경로

환경 변수는 반드시 다음 경로에서 로드됩니다:

```python
load_dotenv("C:/env/.env")
```

**중요 사항**:
- 경로는 `C:/env/.env`로 고정되어 있습니다
- 해당 경로에 `.env` 파일이 반드시 있어야 합니다
- 파일 형식: `OPENAI_API_KEY=your_key_here`

### 경로 변경이 필요한 경우

다른 경로를 사용하려면 다음 파일들을 수정하세요:

- `vector_store_manager.py`: `load_dotenv("C:/env/.env")` 수정
- `topic_classifier.py`: `load_dotenv("C:/env/.env")` 수정
- `agent.py`: `load_dotenv("C:/env/.env")` 수정

## 📦 주요 의존성

- `streamlit`: 웹 UI 프레임워크
- `langchain`: LangChain 핵심 라이브러리
- `langchain-openai`: OpenAI 통합
- `langchain-community`: 커뮤니티 로더 및 벡터스토어
- `faiss-cpu`: FAISS 벡터스토어
- `pypdf`: PDF 파일 파싱
- `openai`: OpenAI API 클라이언트
- `scikit-learn`: 유사도 계산용

## 🔧 문제 해결

### 벡터스토어 로드 실패

- `vector_store/` 폴더가 손상된 경우 삭제 후 재생성
- FAISS 버전 호환성 문제 확인

### 주제 분류 실패

- OpenAI API 키 확인
- `topic_classifier.pkl` 파일 삭제 후 재생성

### PDF 로드 실패

- `pdf_data/` 폴더 존재 확인
- PDF 파일이 손상되지 않았는지 확인
- PyPDF 버전 호환성 확인

## 📝 라이선스

이 프로젝트는 교육 및 연구 목적으로 제공됩니다.

## 👤 작성자

AI Agent PDF Search Project

---

**참고**: 이 프로젝트는 LangChain v1.0의 최신 API를 사용합니다. 이전 버전과는 호환되지 않을 수 있습니다.

