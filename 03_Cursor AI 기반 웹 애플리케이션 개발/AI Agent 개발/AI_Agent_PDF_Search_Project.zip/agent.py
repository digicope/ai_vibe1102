"""
LangChain Agent 모듈
create_agent()를 사용하여 PDF 검색 Agent를 생성합니다.
"""
import os
from typing import List, Optional
from langchain.agents import create_agent
from langchain.tools import tool
from langchain_openai import ChatOpenAI
from langchain_core.documents import Document
from dotenv import load_dotenv

# 환경 변수 로드
load_dotenv("C:/env/.env")

# 전역 변수 (모듈 간 공유)
_vector_store_manager = None
_topic_classifier = None


def initialize_agent_components(vector_store_manager, topic_classifier):
    """Agent에 필요한 컴포넌트를 초기화합니다."""
    global _vector_store_manager, _topic_classifier
    _vector_store_manager = vector_store_manager
    _topic_classifier = topic_classifier


@tool
def list_topics() -> str:
    """
    현재 자동 생성된 주제 목록을 반환합니다.
    
    Returns:
        주제 목록을 문자열로 반환
    """
    if _topic_classifier is None:
        return "주제 분류기가 초기화되지 않았습니다."
    
    topics = _topic_classifier.get_topics()
    if not topics:
        return "주제가 아직 생성되지 않았습니다."
    
    result = "현재 사용 가능한 주제 목록:\n"
    for i, topic in enumerate(topics, 1):
        doc_count = len(_topic_classifier.get_docs_by_topic(topic))
        result += f"{i}. {topic} ({doc_count}개 문서)\n"
    
    return result


@tool
def get_topic_docs(topic: str) -> str:
    """
    특정 주제에 속한 문서 파일명 리스트를 반환합니다.
    
    Args:
        topic: 주제명
        
    Returns:
        해당 주제의 문서 파일명 리스트
    """
    if _topic_classifier is None:
        return "주제 분류기가 초기화되지 않았습니다."
    
    docs = _topic_classifier.get_docs_by_topic(topic)
    if not docs:
        return f"'{topic}' 주제에 속한 문서가 없습니다."
    
    result = f"'{topic}' 주제에 속한 문서 ({len(docs)}개):\n"
    for i, doc in enumerate(docs, 1):
        result += f"{i}. {doc}\n"
    
    return result


@tool
def search_vectorstore(query: str, topic: Optional[str] = None, k: int = 5) -> str:
    """
    벡터스토어에서 유사도 검색을 수행합니다.
    특정 주제가 지정되면 해당 주제의 문서만 검색합니다.
    
    Args:
        query: 검색 쿼리
        topic: 검색할 주제 (선택사항)
        k: 반환할 문서 수 (기본값: 5)
        
    Returns:
        검색된 문서 내용
    """
    if _vector_store_manager is None:
        return "벡터스토어가 초기화되지 않았습니다."
    
    try:
        # 주제가 지정된 경우, 해당 주제의 문서만 필터링
        if topic and _topic_classifier:
            topic_docs = _topic_classifier.get_docs_by_topic(topic)
            if topic_docs:
                # FAISS는 메타데이터 필터를 직접 지원하지 않으므로,
                # 더 많은 결과를 검색한 후 필터링하는 방식으로 처리
                results = _vector_store_manager.search(query, k=k * 5)
                filtered_results = [
                    doc for doc in results
                    if doc.metadata.get("source_file") in topic_docs
                ]
                results = filtered_results[:k]
            else:
                results = _vector_store_manager.search(query, k=k)
        else:
            results = _vector_store_manager.search(query, k=k)
        
        if not results:
            return "검색 결과가 없습니다."
        
        result_text = f"검색 결과 ({len(results)}개 문서 청크):\n\n"
        for i, doc in enumerate(results, 1):
            source_file = doc.metadata.get("source_file", "Unknown")
            page = doc.metadata.get("page", "N/A")
            content = doc.page_content[:1000]  # 더 많은 내용 포함
            
            result_text += f"[{i}] 파일명: {source_file} | 페이지: {page}\n"
            result_text += f"원문: {content}\n\n"
        
        return result_text
    except Exception as e:
        return f"검색 중 오류 발생: {str(e)}"


@tool
def summarize_docs(doc_contents: str) -> str:
    """
    검색된 문서 청크들을 통합 요약합니다.
    
    Args:
        doc_contents: 검색된 문서 내용
        
    Returns:
        요약된 내용
    """
    if not doc_contents or doc_contents.strip() == "":
        return "요약할 내용이 없습니다."
    
    from langchain_openai import ChatOpenAI
    
    llm = ChatOpenAI(model="gpt-4o-mini", temperature=0)
    
    prompt = f"""다음은 여러 문서에서 검색된 내용입니다.
이 내용을 바탕으로 사용자의 질문에 대한 상세하고 포괄적인 답변을 작성하세요.

검색된 문서 내용:
{doc_contents[:8000]}  # 최대 8000자 사용

답변 작성 지침:
1. **상세한 핵심 답변**: 질문에 대한 명확하고 자세한 답변을 작성하세요.
   - 단순히 한 문장으로 답변하지 말고, 관련된 배경 정보, 세부사항, 맥락을 포함하세요.
   - 가능한 한 구체적이고 정확한 정보를 제공하세요.
   - 관련된 개념이나 용어가 있다면 설명하세요.

2. **근거 원문**: 답변의 근거가 된 원문 문장을 인용 형식으로 명시하세요.
   - 여러 근거가 있다면 모두 포함하세요.
   - 각 근거는 충분한 맥락을 포함하여 인용하세요.

3. **참조 정보**: 각 근거에 대한 출처 정보를 명시하세요.
   - 파일명: [PDF 파일명]
   - 페이지: [페이지 번호]

4. **추가 설명**: 관련된 추가 정보나 맥락이 있다면 포함하세요.

답변은 최소 3-5문단으로 구성하여 충분히 자세하게 작성하세요.
답변:"""
    
    try:
        response = llm.invoke(prompt)
        return response.content
    except Exception as e:
        return f"요약 생성 중 오류 발생: {str(e)}"


def create_pdf_search_agent():
    """
    PDF 검색 Agent를 생성합니다.
    
    Returns:
        LangChain Agent 객체
    """
    system_prompt = """너는 PDF 통합 지능형 검색 Agent이다.

주요 역할:
1. 사용자의 질문을 이해하고 가장 관련 있는 주제를 자동으로 판단
2. 해당 주제의 PDF 문서에서 정보를 검색
3. 검색 결과를 바탕으로 명확하고 근거 있는 답변 제공

사용 가능한 도구:
- list_topics: 현재 사용 가능한 주제 목록 조회
- get_topic_docs: 특정 주제에 속한 문서 목록 조회
- search_vectorstore: 벡터스토어에서 유사도 검색 수행 (topic 파라미터로 주제 필터링 가능)
- summarize_docs: 검색된 문서 내용을 요약

작업 흐름:
1. 사용자 질문을 받으면 먼저 list_topics로 주제 목록 확인
2. 질문 내용을 분석하여 가장 관련 있는 주제를 판단
3. 해당 주제로 search_vectorstore를 호출하여 관련 문서 검색
4. 검색 결과를 summarize_docs로 요약하여 최종 답변 생성

답변 형식:
- 상세하고 포괄적인 답변을 작성하세요 (최소 3-5문단)
- 단순히 한 문장으로 답변하지 말고, 배경 정보, 세부사항, 맥락을 포함하세요
- 각 답변의 근거가 된 원문 문장을 인용 형식으로 명시
- 각 근거마다 반드시 다음 정보를 포함:
  * 참조한 PDF 파일명
  * 해당 문서의 페이지 번호
- 필요시 여러 주제의 정보를 종합하여 답변
- 관련된 추가 정보나 맥락이 있다면 포함하세요

답변 작성 시:
- 질문에 대한 직접적인 답변을 먼저 제공하세요
- 답변의 배경이나 맥락을 설명하세요
- 관련된 세부사항이나 예시를 포함하세요
- 가능한 한 구체적이고 정확한 정보를 제공하세요

예시 형식:
**답변**: [상세한 답변 내용 - 최소 3-5문단으로 구성]

**근거 1**: [원문 문장]
- 파일명: [PDF 파일명]
- 페이지: [페이지 번호]

**근거 2**: [원문 문장]
- 파일명: [PDF 파일명]
- 페이지: [페이지 번호]"""
    
    model = ChatOpenAI(model="gpt-4o-mini", temperature=0)
    
    tools = [
        list_topics,
        get_topic_docs,
        search_vectorstore,
        summarize_docs
    ]
    
    agent = create_agent(
        model=model,
        tools=tools,
        system_prompt=system_prompt
    )
    
    return agent


def get_search_results_with_metadata(query: str, topic: Optional[str] = None, k: int = 5) -> List[dict]:
    """
    검색 결과를 메타데이터와 함께 반환합니다.
    
    Args:
        query: 검색 쿼리
        topic: 검색할 주제 (선택사항)
        k: 반환할 문서 수
        
    Returns:
        검색 결과 리스트 (각 항목은 content, source_file, page를 포함)
    """
    if _vector_store_manager is None:
        return []
    
    try:
        # 주제가 지정된 경우, 해당 주제의 문서만 필터링
        if topic and _topic_classifier:
            topic_docs = _topic_classifier.get_docs_by_topic(topic)
            if topic_docs:
                results = _vector_store_manager.search(query, k=k * 5)
                filtered_results = [
                    doc for doc in results
                    if doc.metadata.get("source_file") in topic_docs
                ]
                results = filtered_results[:k]
            else:
                results = _vector_store_manager.search(query, k=k)
        else:
            results = _vector_store_manager.search(query, k=k)
        
        # 결과를 딕셔너리 형태로 변환
        search_results = []
        for doc in results:
            search_results.append({
                'content': doc.page_content,
                'source_file': doc.metadata.get("source_file", "Unknown"),
                'page': doc.metadata.get("page", "N/A")
            })
        
        return search_results
    except Exception as e:
        print(f"검색 결과 가져오기 오류: {str(e)}")
        return []


def invoke_agent(agent, user_query: str) -> str:
    """
    Agent를 호출하여 사용자 질문에 대한 답변을 얻습니다.
    
    Args:
        agent: LangChain Agent 객체
        user_query: 사용자 질문
        
    Returns:
        Agent의 답변
    """
    try:
        result = agent.invoke({
            "messages": [
                {"role": "user", "content": user_query}
            ]
        })
        
        # result["messages"][-1].content로 결과 읽기
        if "messages" in result and len(result["messages"]) > 0:
            last_message = result["messages"][-1]
            if hasattr(last_message, "content"):
                return last_message.content
            elif isinstance(last_message, dict) and "content" in last_message:
                return last_message["content"]
        
        return "답변을 생성할 수 없습니다."
    except Exception as e:
        return f"Agent 실행 중 오류 발생: {str(e)}"


if __name__ == "__main__":
    # 테스트 코드
    print("Agent 모듈 로드 완료")
    print("사용 가능한 도구:")
    print("  - list_topics")
    print("  - get_topic_docs")
    print("  - search_vectorstore")
    print("  - summarize_docs")

