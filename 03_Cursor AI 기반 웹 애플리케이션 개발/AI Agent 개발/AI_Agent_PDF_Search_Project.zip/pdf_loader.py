"""
PDF 로더 모듈
LangChain PDF 로더를 사용하여 PDF 파일을 로드하고 텍스트를 추출합니다.
"""
import os
from pathlib import Path
from typing import List
from langchain_community.document_loaders import PyPDFLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_core.documents import Document


def load_pdfs_from_directory(directory_path: str) -> List[Document]:
    """
    지정된 디렉토리에서 모든 PDF 파일을 로드합니다.
    
    Args:
        directory_path: PDF 파일이 있는 디렉토리 경로
        
    Returns:
        로드된 모든 문서의 리스트
    """
    pdf_dir = Path(directory_path)
    if not pdf_dir.exists():
        raise ValueError(f"디렉토리가 존재하지 않습니다: {directory_path}")
    
    all_documents = []
    pdf_files = list(pdf_dir.glob("*.pdf"))
    
    if not pdf_files:
        print(f"경고: {directory_path}에 PDF 파일이 없습니다.")
        return all_documents
    
    print(f"총 {len(pdf_files)}개의 PDF 파일을 발견했습니다.")
    
    for pdf_file in pdf_files:
        try:
            print(f"로딩 중: {pdf_file.name}")
            loader = PyPDFLoader(str(pdf_file))
            documents = loader.load()
            
            # 각 문서에 파일명 메타데이터 추가
            for doc in documents:
                doc.metadata["source_file"] = pdf_file.name
                doc.metadata["file_path"] = str(pdf_file)
            
            all_documents.extend(documents)
            print(f"  ✓ {len(documents)}페이지 로드 완료")
        except Exception as e:
            print(f"  ✗ 오류 발생 ({pdf_file.name}): {str(e)}")
            continue
    
    print(f"\n총 {len(all_documents)}개의 문서 청크를 로드했습니다.")
    return all_documents


def split_documents(
    documents: List[Document],
    chunk_size: int = 1000,
    chunk_overlap: int = 200
) -> List[Document]:
    """
    문서를 청크로 분할합니다.
    
    Args:
        documents: 분할할 문서 리스트
        chunk_size: 청크 크기
        chunk_overlap: 청크 간 겹치는 부분의 크기
        
    Returns:
        분할된 문서 리스트
    """
    text_splitter = RecursiveCharacterTextSplitter(
        chunk_size=chunk_size,
        chunk_overlap=chunk_overlap,
        length_function=len,
        separators=["\n\n", "\n", " ", ""]
    )
    
    split_docs = text_splitter.split_documents(documents)
    print(f"문서를 {len(split_docs)}개의 청크로 분할했습니다.")
    
    return split_docs


if __name__ == "__main__":
    # 테스트 코드
    docs = load_pdfs_from_directory("pdf_data")
    if docs:
        split_docs = split_documents(docs)
        print(f"\n첫 번째 청크 샘플:")
        print(f"파일: {split_docs[0].metadata.get('source_file', 'Unknown')}")
        print(f"내용 (처음 200자): {split_docs[0].page_content[:200]}...")

