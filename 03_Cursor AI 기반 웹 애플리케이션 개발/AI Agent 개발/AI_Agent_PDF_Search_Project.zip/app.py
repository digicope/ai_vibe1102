"""
Streamlit UI 애플리케이션
PDF 검색 및 질의응답 Agent 시스템의 메인 UI
"""
import streamlit as st
import os
import pickle
from pathlib import Path
from collections import defaultdict
from pdf_loader import load_pdfs_from_directory, split_documents
from vector_store_manager import VectorStoreManager
from topic_classifier import TopicClassifier
from agent import create_pdf_search_agent, initialize_agent_components, invoke_agent, get_search_results_with_metadata
from knowledge_graph import KnowledgeGraph

# 페이지 설정
st.set_page_config(
    page_title="PDF 지능형 검색 Agent",
    page_icon="📚",
    layout="wide"
)

# 세션 상태 초기화
if "vector_store_manager" not in st.session_state:
    st.session_state.vector_store_manager = None
if "topic_classifier" not in st.session_state:
    st.session_state.topic_classifier = None
if "agent" not in st.session_state:
    st.session_state.agent = None
if "topics" not in st.session_state:
    st.session_state.topics = []
if "initialized" not in st.session_state:
    st.session_state.initialized = False
if "knowledge_graph" not in st.session_state:
    st.session_state.knowledge_graph = None
if "topic_graph_path" not in st.session_state:
    st.session_state.topic_graph_path = None


def save_topic_classifier(classifier: TopicClassifier, filepath: str = "topic_classifier.pkl"):
    """주제 분류기를 디스크에 저장합니다. (데이터만 저장, 객체는 저장하지 않음)"""
    try:
        # pickle로 저장할 수 없는 객체(embeddings, llm)를 제외하고 데이터만 저장
        data_to_save = {
            'topic_to_docs': dict(classifier.topic_to_docs),
            'doc_to_topic': dict(classifier.doc_to_topic),
            'topic_to_keywords': dict(classifier.topic_to_keywords)
        }
        
        # 임시 파일로 먼저 저장한 후 원본 파일로 이동 (원자적 저장)
        temp_filepath = filepath + ".tmp"
        
        # 기존 임시 파일이 있으면 삭제
        if os.path.exists(temp_filepath):
            os.remove(temp_filepath)
        
        with open(temp_filepath, "wb") as f:
            pickle.dump(data_to_save, f, protocol=pickle.HIGHEST_PROTOCOL)
        
        # 저장이 완료된 후 원본 파일 교체
        if os.path.exists(filepath):
            os.remove(filepath)
        os.rename(temp_filepath, filepath)
        
        return True
    except Exception as e:
        st.error(f"주제 분류기 저장 실패: {str(e)}")
        # 임시 파일 정리
        try:
            if os.path.exists(filepath + ".tmp"):
                os.remove(filepath + ".tmp")
        except:
            pass
        return False


def load_topic_classifier(filepath: str = "topic_classifier.pkl") -> TopicClassifier:
    """디스크에서 주제 분류기 데이터를 불러와 새로운 인스턴스를 생성합니다."""
    try:
        if not os.path.exists(filepath):
            return None
        
        # 파일 크기 확인 (비어있는 파일 체크)
        file_size = os.path.getsize(filepath)
        if file_size == 0:
            st.warning("주제 분류기 파일이 비어있습니다. 삭제하고 재생성합니다.")
            os.remove(filepath)
            return None
        
        with open(filepath, "rb") as f:
            data = pickle.load(f)
        
        # 데이터 유효성 확인
        if not isinstance(data, dict) or 'topic_to_docs' not in data or 'doc_to_topic' not in data:
            st.warning("주제 분류기 파일 형식이 올바르지 않습니다. 재생성합니다.")
            if os.path.exists(filepath):
                os.remove(filepath)
            return None
        
        # 새로운 TopicClassifier 인스턴스 생성 및 데이터 복원
        classifier = TopicClassifier()
        classifier.topic_to_docs = defaultdict(list, data['topic_to_docs'])
        classifier.doc_to_topic = data['doc_to_topic']
        # topic_to_keywords는 선택적 (이전 버전 호환성)
        if 'topic_to_keywords' in data:
            classifier.topic_to_keywords = defaultdict(list, data['topic_to_keywords'])
        
        # 유효성 확인
        if not hasattr(classifier, 'get_topics') or len(classifier.get_topics()) == 0:
            st.warning("주제 분류기 데이터가 비어있습니다. 재생성합니다.")
            if os.path.exists(filepath):
                os.remove(filepath)
            return None
            
        return classifier
    except (EOFError, pickle.UnpicklingError) as e:
        # pickle 파일이 손상된 경우
        st.warning(f"주제 분류기 파일이 손상되었습니다: {str(e)}. 재생성합니다.")
        try:
            if os.path.exists(filepath):
                os.remove(filepath)
        except:
            pass
        return None
    except Exception as e:
        st.warning(f"주제 분류기 불러오기 실패: {str(e)}. 재생성합니다.")
        try:
            if os.path.exists(filepath):
                os.remove(filepath)
        except:
            pass
        return None


def initialize_system():
    """시스템 초기화: 벡터스토어 및 주제 분류"""
    with st.spinner("시스템 초기화 중..."):
        # 1. 벡터스토어 관리자 초기화
        vector_store_manager = VectorStoreManager()
        
        # 2. 벡터스토어 불러오기 또는 생성
        if vector_store_manager.exists():
            st.info("기존 벡터스토어를 불러오는 중...")
            if vector_store_manager.load_vector_store():
                st.success("✓ 벡터스토어 불러오기 완료")
            else:
                st.warning("벡터스토어 불러오기 실패. 새로 생성합니다.")
                create_new_vector_store(vector_store_manager)
        else:
            st.info("새 벡터스토어를 생성합니다...")
            create_new_vector_store(vector_store_manager)
        
        # 3. 주제 분류기 불러오기 또는 생성
        try:
            topic_classifier = load_topic_classifier()
            
            if topic_classifier is None:
                st.info("주제 분류를 수행합니다...")
                topic_classifier = create_topic_classification(vector_store_manager)
                if topic_classifier:
                    save_topic_classifier(topic_classifier)
                    st.success("✓ 주제 분류 완료")
            elif not hasattr(topic_classifier, 'get_topics') or len(topic_classifier.get_topics()) == 0:
                st.warning("주제 분류기가 비어있습니다. 재생성합니다.")
                topic_classifier = create_topic_classification(vector_store_manager)
                if topic_classifier:
                    save_topic_classifier(topic_classifier)
                    st.success("✓ 주제 분류 완료")
            else:
                st.success("✓ 기존 주제 분류 정보 불러오기 완료")
        except Exception as e:
            st.warning(f"주제 분류기 처리 중 오류 발생: {str(e)}")
            st.info("주제 분류를 재수행합니다...")
            try:
                topic_classifier = create_topic_classification(vector_store_manager)
                if topic_classifier:
                    save_topic_classifier(topic_classifier)
                    st.success("✓ 주제 분류 완료")
            except Exception as e2:
                st.error(f"주제 분류 생성 실패: {str(e2)}")
                topic_classifier = TopicClassifier()  # 빈 분류기로 초기화
        
        # 4. Agent 생성 및 초기화
        agent = create_pdf_search_agent()
        initialize_agent_components(vector_store_manager, topic_classifier)
        
        # 5. Knowledge Graph 초기화
        knowledge_graph = KnowledgeGraph()
        
        # 세션 상태에 저장
        st.session_state.vector_store_manager = vector_store_manager
        st.session_state.topic_classifier = topic_classifier
        st.session_state.agent = agent
        st.session_state.topics = topic_classifier.get_topics()
        st.session_state.knowledge_graph = knowledge_graph
        st.session_state.initialized = True
        
        # 주제 관계 그래프 생성
        try:
            st.info("주제 관계 그래프 생성 중...")
            topic_keywords = {
                topic: topic_classifier.get_topic_keywords(topic)
                for topic in st.session_state.topics
            }
            topic_docs = {
                topic: topic_classifier.get_docs_by_topic(topic)
                for topic in st.session_state.topics
            }
            
            graph_path = knowledge_graph.create_topic_graph(
                topics=st.session_state.topics,
                topic_keywords=topic_keywords,
                topic_docs=topic_docs,
                top_k=3
            )
            
            if graph_path:
                st.session_state.topic_graph_path = graph_path
                st.success("✓ 주제 관계 그래프 생성 완료")
            else:
                st.warning("주제 관계 그래프 생성 실패")
        except Exception as e:
            st.warning(f"주제 관계 그래프 생성 중 오류: {str(e)}")
        
        return True


def create_new_vector_store(vector_store_manager: VectorStoreManager):
    """새 벡터스토어를 생성합니다."""
    # PDF 로드
    pdf_dir = "pdf_data"
    if not os.path.exists(pdf_dir):
        st.error(f"PDF 디렉토리가 없습니다: {pdf_dir}")
        return False
    
    documents = load_pdfs_from_directory(pdf_dir)
    if not documents:
        st.error("PDF 파일을 찾을 수 없습니다.")
        return False
    
    # 문서 분할
    split_docs = split_documents(documents)
    
    # 벡터스토어 생성
    vector_store_manager.create_vector_store(split_docs)
    vector_store_manager.save_vector_store()
    
    return True


def create_topic_classification(vector_store_manager: VectorStoreManager) -> TopicClassifier:
    """주제 분류를 수행합니다."""
    # 벡터스토어에서 모든 문서 가져오기
    # (실제로는 원본 문서 리스트가 필요하므로 다시 로드)
    pdf_dir = "pdf_data"
    documents = load_pdfs_from_directory(pdf_dir)
    split_docs = split_documents(documents)
    
    # 주제 분류
    topic_classifier = TopicClassifier()
    topic_classifier.classify_documents(split_docs)
    
    return topic_classifier


def main():
    """메인 UI"""
    st.title("📚 PDF 지능형 검색 Agent")
    st.markdown("---")
    
    # 사이드바: 초기화 및 정보
    with st.sidebar:
        st.header("⚙️ 시스템 설정")
        
        if st.button("🔄 시스템 초기화", type="primary"):
            st.session_state.initialized = False
            initialize_system()
        
        if st.session_state.initialized:
            st.success("✓ 시스템 준비 완료")
            st.info(f"주제 수: {len(st.session_state.topics)}개")
        else:
            st.warning("시스템이 초기화되지 않았습니다.")
            if st.button("초기화 시작"):
                initialize_system()
    
    # 메인 영역
    if not st.session_state.initialized:
        st.info("👈 사이드바에서 '시스템 초기화' 버튼을 클릭하세요.")
        if st.button("자동 초기화"):
            initialize_system()
        return
    
    # 주제 목록 표시
    st.header("📋 주제 목록")
    
    # AI Knowledge Graph 섹션 추가
    st.subheader("🕸️ AI Knowledge Graph - 주제 관계 그래프")
    
    if st.session_state.topic_graph_path and os.path.exists(st.session_state.topic_graph_path):
        st.image(st.session_state.topic_graph_path)
        st.caption("💡 주제 간 유사도 기반 관계 그래프. 연결된 주제들은 서로 관련성이 높습니다.")
    else:
        st.info("주제 관계 그래프를 생성 중입니다...")
        if st.session_state.topics and st.session_state.knowledge_graph:
            try:
                topic_keywords = {
                    topic: st.session_state.topic_classifier.get_topic_keywords(topic)
                    for topic in st.session_state.topics
                }
                topic_docs = {
                    topic: st.session_state.topic_classifier.get_docs_by_topic(topic)
                    for topic in st.session_state.topics
                }
                
                graph_path = st.session_state.knowledge_graph.create_topic_graph(
                    topics=st.session_state.topics,
                    topic_keywords=topic_keywords,
                    topic_docs=topic_docs,
                    top_k=3
                )
                
                if graph_path:
                    st.session_state.topic_graph_path = graph_path
                    st.rerun()
            except Exception as e:
                st.error(f"그래프 생성 오류: {str(e)}")
    
    st.markdown("---")
    
    if st.session_state.topics:
        # 주제를 탭으로 표시
        selected_topic = st.selectbox(
            "검색할 주제를 선택하세요 (선택사항):",
            ["전체"] + st.session_state.topics,
            key="topic_selector"
        )
        
        # 선택된 주제의 상세 정보 표시
        if selected_topic != "전체":
            st.subheader(f"📄 '{selected_topic}' 주제 상세 정보")
            
            # 총 문서 개수
            topic_docs = st.session_state.topic_classifier.get_docs_by_topic(selected_topic)
            doc_count = len(topic_docs)
            
            # 정보를 컬럼으로 표시
            col1, col2 = st.columns([1, 2])
            
            with col1:
                st.metric("📊 총 문서 개수", f"{doc_count}개")
            
            with col2:
                st.write("")  # 공간 맞추기
            
            # 핵심 키워드
            keywords = st.session_state.topic_classifier.get_topic_keywords(selected_topic)
            if keywords:
                st.write("**🔑 핵심 키워드:**")
                # 키워드를 태그 형태로 표시
                keyword_tags = " ".join([f"`{kw}`" for kw in keywords[:10]])  # 최대 10개
                st.markdown(keyword_tags)
            else:
                st.info("키워드 정보가 없습니다.")
            
            st.markdown("---")
            
            # 질의문 예시
            with st.spinner("질의문 예시 생성 중..."):
                query_examples = st.session_state.topic_classifier.generate_query_examples(selected_topic, num_examples=5)
                if query_examples:
                    st.write("**💡 질의문 예시:**")
                    for i, example in enumerate(query_examples, 1):
                        st.write(f"{i}. {example}")
                else:
                    st.info("질의문 예시를 생성할 수 없습니다.")
            
            st.markdown("---")
            
            # 문서 목록
            st.write("**📚 포함된 문서:**")
            if topic_docs:
                for i, doc in enumerate(topic_docs, 1):
                    st.write(f"{i}. {doc}")
            else:
                st.info("이 주제에 속한 문서가 없습니다.")
            
            st.markdown("---")
            
            # 주제 간 관계 그래프가 이미 위에 표시되므로 문서 레벨 그래프는 제거
            # (같은 주제 내 문서들은 이미 관련이 있어서 별도 그래프가 불필요)
        else:
            st.info("모든 주제의 문서를 검색합니다.")
    else:
        st.warning("주제가 생성되지 않았습니다.")
        selected_topic = None
    
    st.markdown("---")
    
    # 질의응답 영역
    st.header("💬 질의응답")
    
    # 질문 입력 (세션 상태로 관리)
    if "user_query_input" not in st.session_state:
        st.session_state.user_query_input = ""
    if "clear_input_counter" not in st.session_state:
        st.session_state.clear_input_counter = 0
    
    # 입력란과 지우기 버튼을 같은 행에 배치
    col_input, col_clear = st.columns([10, 1])
    
    with col_input:
        # clear_input_counter를 key에 포함하여 버튼 클릭 시 새로운 위젯 생성
        user_query = st.text_area(
            "질문을 입력하세요:",
            value=st.session_state.user_query_input,
            height=100,
            placeholder="예: 기후 변화가 에너지 정책에 미치는 영향은?",
            key=f"query_input_area_{st.session_state.clear_input_counter}"
        )
    
    with col_clear:
        st.write("")  # 공간 맞추기
        st.write("")  # 공간 맞추기
        # 작은 회색 X 버튼
        clear_button = st.button("✕", help="입력란 지우기", use_container_width=False, key="clear_query_button")
        
        # 버튼 스타일 조정 (CSS)
        st.markdown("""
        <style>
        div[data-testid="stButton"] > button[kind="secondary"] {
            width: 40px;
            height: 40px;
            padding: 0;
            color: #666666;
            background-color: #f0f0f0;
            border: 1px solid #cccccc;
        }
        div[data-testid="stButton"] > button[kind="secondary"]:hover {
            background-color: #e0e0e0;
            border-color: #999999;
        }
        </style>
        """, unsafe_allow_html=True)
    
    # 지우기 버튼 클릭 시 입력란 초기화
    if clear_button:
        st.session_state.clear_input_counter += 1
        st.session_state.user_query_input = ""
        st.rerun()  # 페이지 새로고침하여 입력란 초기화
    
    # 입력값을 세션 상태에 저장 (항상 최신값 유지)
    if user_query:
        st.session_state.user_query_input = user_query
    
    # 최종 입력값 결정 (세션 상태 우선)
    final_query = st.session_state.user_query_input if st.session_state.user_query_input else user_query
    
    col1, col2 = st.columns([1, 4])
    with col1:
        search_button = st.button("🔍 검색", type="primary", use_container_width=True)
    
    # 검색 실행
    if search_button and final_query:
        with st.spinner("Agent가 답변을 생성하는 중..."):
            try:
                # 검색 결과 가져오기 (근거 정보 표시용)
                search_topic = selected_topic if selected_topic and selected_topic != "전체" else None
                search_results = get_search_results_with_metadata(final_query, topic=search_topic, k=5)
                
                # Agent 호출
                response = invoke_agent(st.session_state.agent, final_query)
                
                # 결과 표시
                st.subheader("📝 답변")
                st.markdown(response)
                
                # 근거 정보 표시
                if search_results:
                    st.markdown("---")
                    st.subheader("📚 근거 정보")
                    
                    for i, result in enumerate(search_results, 1):
                        with st.expander(f"근거 {i}: {result['source_file']} (페이지 {result['page']})"):
                            st.write("**원문 문장:**")
                            # 원문에서 핵심 문장 추출 (처음 500자)
                            content_preview = result['content'][:500]
                            if len(result['content']) > 500:
                                content_preview += "..."
                            st.write(content_preview)
                            
                            st.write("**참조 정보:**")
                            col1, col2 = st.columns(2)
                            with col1:
                                st.write(f"📄 **파일명**: {result['source_file']}")
                            with col2:
                                st.write(f"📑 **페이지**: {result['page']}")
                
                # 선택된 주제 정보 표시
                if selected_topic and selected_topic != "전체":
                    st.info(f"💡 '{selected_topic}' 주제의 문서를 기반으로 검색되었습니다.")
                
            except Exception as e:
                st.error(f"오류 발생: {str(e)}")
                st.exception(e)
    
    # 주제 목록 상세 표시
    st.markdown("---")
    with st.expander("📊 전체 주제 및 문서 목록"):
        if st.session_state.topics:
            for topic in st.session_state.topics:
                st.subheader(f"📌 {topic}")
                docs = st.session_state.topic_classifier.get_docs_by_topic(topic)
                for doc in docs:
                    st.write(f"  - {doc}")
        else:
            st.info("주제가 없습니다.")


if __name__ == "__main__":
    # 자동 초기화 (첫 실행 시)
    if not st.session_state.initialized:
        initialize_system()
    
    main()

