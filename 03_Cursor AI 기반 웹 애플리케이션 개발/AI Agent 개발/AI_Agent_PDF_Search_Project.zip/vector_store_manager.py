"""
벡터스토어 관리 모듈
FAISS 벡터스토어를 생성, 저장, 불러오기를 관리합니다.
"""
import os
from pathlib import Path
from typing import List, Optional
from langchain_core.documents import Document
from langchain_openai import OpenAIEmbeddings
from langchain_community.vectorstores import FAISS
from dotenv import load_dotenv

# 환경 변수 로드
load_dotenv("C:/env/.env")


class VectorStoreManager:
    """벡터스토어 생성 및 관리 클래스"""
    
    def __init__(self, vector_store_path: str = "vector_store"):
        """
        Args:
            vector_store_path: 벡터스토어를 저장할 디렉토리 경로
        """
        self.vector_store_path = vector_store_path
        self.embeddings = OpenAIEmbeddings(model="text-embedding-3-small")
        self.vector_store: Optional[FAISS] = None
    
    def create_vector_store(self, documents: List[Document]) -> FAISS:
        """
        문서 리스트로부터 벡터스토어를 생성합니다.
        
        Args:
            documents: 임베딩할 문서 리스트
            
        Returns:
            생성된 FAISS 벡터스토어
        """
        if not documents:
            raise ValueError("문서 리스트가 비어있습니다.")
        
        print(f"\n벡터스토어 생성 중... ({len(documents)}개 문서)")
        print("임베딩 생성 중... (시간이 걸릴 수 있습니다)")
        
        self.vector_store = FAISS.from_documents(
            documents=documents,
            embedding=self.embeddings
        )
        
        print("✓ 벡터스토어 생성 완료")
        return self.vector_store
    
    def save_vector_store(self) -> None:
        """현재 벡터스토어를 디스크에 저장합니다."""
        if self.vector_store is None:
            raise ValueError("저장할 벡터스토어가 없습니다.")
        
        vector_store_dir = Path(self.vector_store_path)
        vector_store_dir.mkdir(exist_ok=True)
        
        print(f"\n벡터스토어 저장 중: {self.vector_store_path}")
        self.vector_store.save_local(self.vector_store_path)
        print("✓ 벡터스토어 저장 완료")
    
    def load_vector_store(self) -> bool:
        """
        디스크에서 벡터스토어를 불러옵니다.
        
        Returns:
            불러오기 성공 여부
        """
        vector_store_dir = Path(self.vector_store_path)
        
        # index.faiss 파일이 존재하는지 확인
        index_file = vector_store_dir / "index.faiss"
        if not index_file.exists():
            return False
        
        try:
            print(f"\n기존 벡터스토어 불러오기: {self.vector_store_path}")
            self.vector_store = FAISS.load_local(
                self.vector_store_path,
                self.embeddings,
                allow_dangerous_deserialization=True
            )
            print("✓ 벡터스토어 불러오기 완료")
            return True
        except Exception as e:
            print(f"✗ 벡터스토어 불러오기 실패: {str(e)}")
            return False
    
    def get_vector_store(self) -> FAISS:
        """
        현재 벡터스토어를 반환합니다.
        
        Returns:
            FAISS 벡터스토어
        """
        if self.vector_store is None:
            raise ValueError("벡터스토어가 초기화되지 않았습니다.")
        return self.vector_store
    
    def search(self, query: str, k: int = 5, filter_dict: Optional[dict] = None) -> List[Document]:
        """
        벡터스토어에서 유사도 검색을 수행합니다.
        
        Args:
            query: 검색 쿼리
            k: 반환할 문서 수
            filter_dict: 메타데이터 필터 (예: {"source_file": "file.pdf"})
            
        Returns:
            검색된 문서 리스트
        """
        if self.vector_store is None:
            raise ValueError("벡터스토어가 초기화되지 않았습니다.")
        
        if filter_dict:
            return self.vector_store.similarity_search(
                query,
                k=k,
                filter=filter_dict
            )
        else:
            return self.vector_store.similarity_search(query, k=k)
    
    def exists(self) -> bool:
        """
        저장된 벡터스토어가 존재하는지 확인합니다.
        
        Returns:
            존재 여부
        """
        vector_store_dir = Path(self.vector_store_path)
        index_file = vector_store_dir / "index.faiss"
        return index_file.exists()


if __name__ == "__main__":
    # 테스트 코드
    manager = VectorStoreManager()
    
    if manager.exists():
        print("기존 벡터스토어 발견")
        manager.load_vector_store()
    else:
        print("새 벡터스토어 생성 필요")

