"""
주제 분류 모듈
PDF 문서를 임베딩 기반으로 주제별로 자동 분류합니다.
"""
import os
from typing import Dict, List, Set
from collections import defaultdict
from langchain_core.documents import Document
from langchain_openai import OpenAIEmbeddings, ChatOpenAI
from dotenv import load_dotenv

# 환경 변수 로드
load_dotenv("C:/env/.env")


class TopicClassifier:
    """PDF 문서를 주제별로 자동 분류하는 클래스"""
    
    def __init__(self):
        self.embeddings = OpenAIEmbeddings(model="text-embedding-3-small")
        self.llm = ChatOpenAI(model="gpt-4o-mini", temperature=0)
        self.topic_to_docs: Dict[str, List[str]] = defaultdict(list)
        self.doc_to_topic: Dict[str, str] = {}
        self.topic_to_keywords: Dict[str, List[str]] = defaultdict(list)  # 주제별 키워드 저장
    
    def extract_keywords_from_doc(self, doc: Document) -> List[str]:
        """
        문서에서 대표 키워드를 추출합니다.
        
        Args:
            doc: 문서 객체
            
        Returns:
            키워드 리스트
        """
        content = doc.page_content[:2000]  # 처음 2000자만 사용
        
        prompt = f"""다음 문서 내용에서 핵심 키워드 5-7개를 추출하세요.
키워드는 명사 위주로, 문서의 주제를 대표할 수 있는 것들로 선택하세요.

문서 내용:
{content}

키워드만 쉼표로 구분하여 출력하세요:"""
        
        try:
            response = self.llm.invoke(prompt)
            keywords = [k.strip() for k in response.content.split(",")]
            return keywords[:7]  # 최대 7개
        except Exception as e:
            print(f"키워드 추출 오류: {str(e)}")
            return []
    
    def generate_topic_name(self, keywords_list: List[List[str]]) -> str:
        """
        키워드 리스트를 기반으로 주제명을 생성합니다.
        
        Args:
            keywords_list: 여러 문서의 키워드 리스트
            
        Returns:
            생성된 주제명
        """
        # 모든 키워드를 하나의 문자열로 합치기
        all_keywords = []
        for keywords in keywords_list:
            all_keywords.extend(keywords)
        
        # 빈도수 계산
        from collections import Counter
        keyword_counts = Counter(all_keywords)
        top_keywords = [kw for kw, _ in keyword_counts.most_common(5)]
        
        keywords_str = ", ".join(top_keywords)
        
        prompt = f"""다음 키워드들을 기반으로 간결하고 명확한 주제명을 생성하세요.
주제명은 2-4단어로 구성하고, 한국어로 작성하세요.

키워드: {keywords_str}

주제명만 출력하세요 (설명 없이):"""
        
        try:
            response = self.llm.invoke(prompt)
            topic_name = response.content.strip()
            # 따옴표 제거
            topic_name = topic_name.strip('"').strip("'")
            return topic_name
        except Exception as e:
            print(f"주제명 생성 오류: {str(e)}")
            return "기타"
    
    def classify_documents(self, documents: List[Document]) -> Dict[str, List[str]]:
        """
        문서들을 주제별로 분류합니다.
        
        Args:
            documents: 분류할 문서 리스트
            
        Returns:
            주제명 -> 파일명 리스트 매핑
        """
        print("\n문서 주제 분류 시작...")
        
        # 1단계: 각 문서에서 키워드 추출
        doc_keywords = {}
        file_groups = defaultdict(list)
        
        for doc in documents:
            source_file = doc.metadata.get("source_file", "unknown")
            if source_file not in doc_keywords:
                doc_keywords[source_file] = []
            
            keywords = self.extract_keywords_from_doc(doc)
            doc_keywords[source_file].extend(keywords)
            file_groups[source_file].append(doc)
        
        print(f"총 {len(file_groups)}개 파일의 키워드 추출 완료")
        
        # 2단계: 파일별로 대표 키워드 집합 생성
        file_representative_keywords = {}
        for file_name, keywords_list in doc_keywords.items():
            # 중복 제거 및 상위 키워드 선택
            from collections import Counter
            keyword_counts = Counter(keywords_list)
            file_representative_keywords[file_name] = [
                kw for kw, _ in keyword_counts.most_common(5)
            ]
        
        # 3단계: 유사한 키워드를 가진 파일들을 그룹화
        # 간단한 클러스터링: 키워드 유사도 기반
        file_to_topic = {}
        topic_groups = defaultdict(list)
        
        # 각 파일의 키워드를 임베딩으로 변환
        file_embeddings = {}
        for file_name, keywords in file_representative_keywords.items():
            keywords_text = " ".join(keywords)
            try:
                embedding = self.embeddings.embed_query(keywords_text)
                file_embeddings[file_name] = embedding
            except Exception as e:
                print(f"임베딩 생성 오류 ({file_name}): {str(e)}")
                continue
        
        # 유사도 기반 클러스터링 (간단한 방법)
        import numpy as np
        from sklearn.metrics.pairwise import cosine_similarity
        
        if len(file_embeddings) == 0:
            print("임베딩 생성 실패")
            return {}
        
        file_names = list(file_embeddings.keys())
        embeddings_matrix = np.array([file_embeddings[f] for f in file_names])
        
        # 코사인 유사도 계산
        similarity_matrix = cosine_similarity(embeddings_matrix)
        
        # 클러스터링 (임계값 기반)
        threshold = 0.7
        clusters = []
        assigned = set()
        
        for i, file_name in enumerate(file_names):
            if file_name in assigned:
                continue
            
            cluster = [file_name]
            assigned.add(file_name)
            
            for j, other_file in enumerate(file_names):
                if i != j and other_file not in assigned:
                    if similarity_matrix[i][j] > threshold:
                        cluster.append(other_file)
                        assigned.add(other_file)
            
            clusters.append(cluster)
        
        # 4단계: 각 클러스터에 주제명 부여
        print(f"\n{len(clusters)}개의 주제 그룹 발견")
        
        for cluster in clusters:
            cluster_keywords = []
            for file_name in cluster:
                cluster_keywords.append(file_representative_keywords[file_name])
            
            topic_name = self.generate_topic_name(cluster_keywords)
            
            # 중복 주제명 처리
            original_topic = topic_name
            counter = 1
            while topic_name in topic_groups:
                topic_name = f"{original_topic}_{counter}"
                counter += 1
            
            for file_name in cluster:
                file_to_topic[file_name] = topic_name
                topic_groups[topic_name].append(file_name)
            
            # 주제별 대표 키워드 저장 (클러스터의 모든 키워드에서 상위 키워드 추출)
            from collections import Counter
            all_cluster_keywords = []
            for kw_list in cluster_keywords:
                all_cluster_keywords.extend(kw_list)
            keyword_counts = Counter(all_cluster_keywords)
            self.topic_to_keywords[topic_name] = [
                kw for kw, _ in keyword_counts.most_common(10)  # 상위 10개 키워드
            ]
        
        # 결과 저장
        self.topic_to_docs = dict(topic_groups)
        self.doc_to_topic = file_to_topic
        
        print("\n주제 분류 완료:")
        for topic, files in topic_groups.items():
            print(f"  - {topic}: {len(files)}개 파일")
        
        return self.topic_to_docs
    
    def get_topics(self) -> List[str]:
        """현재 분류된 주제 목록을 반환합니다."""
        return list(self.topic_to_docs.keys())
    
    def get_docs_by_topic(self, topic: str) -> List[str]:
        """
        특정 주제에 속한 문서 파일명 리스트를 반환합니다.
        
        Args:
            topic: 주제명
            
        Returns:
            파일명 리스트
        """
        return self.topic_to_docs.get(topic, [])
    
    def get_topic_by_doc(self, doc_file: str) -> str:
        """
        문서 파일명으로부터 주제를 찾습니다.
        
        Args:
            doc_file: 파일명
            
        Returns:
            주제명
        """
        return self.doc_to_topic.get(doc_file, "기타")
    
    def get_topic_keywords(self, topic: str) -> List[str]:
        """
        특정 주제의 핵심 키워드 리스트를 반환합니다.
        
        Args:
            topic: 주제명
            
        Returns:
            키워드 리스트
        """
        return self.topic_to_keywords.get(topic, [])
    
    def generate_query_examples(self, topic: str, num_examples: int = 5) -> List[str]:
        """
        특정 주제에 대한 질의문 예시를 생성합니다.
        
        Args:
            topic: 주제명
            num_examples: 생성할 예시 개수
            
        Returns:
            질의문 예시 리스트
        """
        keywords = self.get_topic_keywords(topic)
        if not keywords:
            return []
        
        keywords_str = ", ".join(keywords[:5])  # 상위 5개 키워드만 사용
        
        prompt = f"""다음 주제와 키워드를 바탕으로 사용자가 물어볼 수 있는 질의문 예시 {num_examples}개를 생성하세요.
주제: {topic}
핵심 키워드: {keywords_str}

질의문은 자연스럽고 구체적이어야 하며, 주제와 관련된 실용적인 질문이어야 합니다.
각 질의문을 한 줄씩, 번호 없이 출력하세요:"""
        
        try:
            response = self.llm.invoke(prompt)
            examples = [line.strip() for line in response.content.strip().split('\n') if line.strip()]
            # 번호나 불필요한 문자 제거
            cleaned_examples = []
            for ex in examples:
                # 번호 제거 (예: "1. ", "1) ", "- " 등)
                ex = ex.lstrip('0123456789. )-')
                if ex and len(ex) > 5:  # 너무 짧은 것은 제외
                    cleaned_examples.append(ex)
            return cleaned_examples[:num_examples]
        except Exception as e:
            print(f"질의문 예시 생성 오류: {str(e)}")
            # 기본 예시 생성
            return [f"{topic}에 대해 알려주세요", f"{topic}의 주요 내용은 무엇인가요?"]


if __name__ == "__main__":
    # 테스트 코드
    classifier = TopicClassifier()
    print("TopicClassifier 초기화 완료")

