"""
AI Knowledge Graph 모듈
주제 및 문서 간 관계를 그래프로 시각화합니다.
"""
import os
import numpy as np
import networkx as nx
import matplotlib.pyplot as plt
import matplotlib.font_manager as fm
from typing import Dict, List, Tuple, Optional
from pathlib import Path
from langchain_openai import OpenAIEmbeddings
from dotenv import load_dotenv

# 환경 변수 로드
load_dotenv("C:/env/.env")

# 한글 폰트 설정
plt.rcParams['font.family'] = 'Malgun Gothic'  # Windows 기본 한글 폰트
plt.rcParams['axes.unicode_minus'] = False  # 마이너스 기호 깨짐 방지


class KnowledgeGraph:
    """지식 그래프 생성 및 시각화 클래스"""
    
    def __init__(self):
        self.embeddings = OpenAIEmbeddings(model="text-embedding-3-small")
        self.graph_dir = Path("knowledge_graphs")
        self.graph_dir.mkdir(exist_ok=True)
    
    def calculate_topic_similarity(self, topics: List[str], topic_keywords: Dict[str, List[str]]) -> np.ndarray:
        """
        주제 간 유사도를 계산합니다.
        
        Args:
            topics: 주제 리스트
            topic_keywords: 주제별 키워드 딕셔너리
            
        Returns:
            유사도 행렬
        """
        topic_embeddings = {}
        
        for topic in topics:
            keywords = topic_keywords.get(topic, [])
            if keywords:
                keywords_text = " ".join(keywords[:10])  # 상위 10개 키워드
                try:
                    embedding = self.embeddings.embed_query(keywords_text)
                    topic_embeddings[topic] = embedding
                except Exception as e:
                    print(f"임베딩 생성 오류 ({topic}): {str(e)}")
                    continue
        
        if len(topic_embeddings) == 0:
            return None, []
        
        # 유사도 행렬 계산
        from sklearn.metrics.pairwise import cosine_similarity
        
        topic_list = list(topic_embeddings.keys())
        embeddings_matrix = np.array([topic_embeddings[t] for t in topic_list])
        similarity_matrix = cosine_similarity(embeddings_matrix)
        
        return similarity_matrix, topic_list
    
    def create_topic_graph(
        self,
        topics: List[str],
        topic_keywords: Dict[str, List[str]],
        topic_docs: Dict[str, List[str]],
        top_k: int = 3,
        output_path: Optional[str] = None
    ) -> str:
        """
        주제 레벨 관계 그래프를 생성합니다.
        
        Args:
            topics: 주제 리스트
            topic_keywords: 주제별 키워드 딕셔너리
            topic_docs: 주제별 문서 딕셔너리
            top_k: 각 노드당 최대 연결 수
            output_path: 출력 파일 경로 (None이면 자동 생성)
            
        Returns:
            생성된 이미지 파일 경로
        """
        if not topics:
            return None
        
        # 유사도 계산
        similarity_matrix, topic_list = self.calculate_topic_similarity(topics, topic_keywords)
        if similarity_matrix is None or len(topic_list) == 0:
            return None
        
        # 그래프 생성
        G = nx.Graph()
        
        # 노드 추가
        for topic in topic_list:
            doc_count = len(topic_docs.get(topic, []))
            G.add_node(topic, size=doc_count)
        
        # 엣지 추가 (모든 연결 추가, 유사도에 따라 스타일 구분)
        for i, topic1 in enumerate(topic_list):
            similarities = []
            for j, topic2 in enumerate(topic_list):
                if i != j:
                    similarities.append((j, similarity_matrix[i][j]))
            
            # 상위 K개는 굵은 실선, 나머지는 얇은 점선
            similarities.sort(key=lambda x: x[1], reverse=True)
            top_similarities = similarities[:top_k]
            other_similarities = similarities[top_k:]
            
            # 상위 K개 연결 (굵은 실선)
            for j, sim_score in top_similarities:
                if sim_score > 0.1:  # 낮은 임계값
                    topic2 = topic_list[j]
                    G.add_edge(topic1, topic2, weight=sim_score, style='solid', alpha=0.8)
            
            # 나머지 연결 (얇은 점선)
            for j, sim_score in other_similarities:
                if sim_score > 0.1:  # 낮은 임계값
                    topic2 = topic_list[j]
                    # 이미 연결되어 있지 않은 경우만 추가
                    if not G.has_edge(topic1, topic2):
                        G.add_edge(topic1, topic2, weight=sim_score, style='dashed', alpha=0.3)
        
        # 그래프 시각화
        if output_path is None:
            output_path = self.graph_dir / "topic_graph.png"
        else:
            output_path = Path(output_path)
        
        # 각 주제의 대표 키워드 2-3개 추출
        topic_representative_keywords = {}
        for topic in topic_list:
            keywords = topic_keywords.get(topic, [])
            if keywords and len(keywords) > 0:
                # 상위 2-3개 키워드 선택
                representative = keywords[:3] if len(keywords) >= 3 else keywords
                # 빈 문자열 제거
                representative = [kw for kw in representative if kw and kw.strip()]
                if len(representative) > 0:
                    topic_representative_keywords[topic] = representative
                    print(f"주제 '{topic}' 키워드: {representative}")  # 디버깅
                else:
                    # 키워드가 모두 빈 문자열이면 주제명에서 추출
                    topic_words = [w for w in topic.split() if len(w) > 1][:3]
                    topic_representative_keywords[topic] = topic_words
                    print(f"주제 '{topic}': 키워드 없음, 주제명에서 추출: {topic_words}")  # 디버깅
            else:
                # 키워드가 없으면 주제명에서 추출
                topic_words = [w for w in topic.split() if len(w) > 1][:3]
                topic_representative_keywords[topic] = topic_words
                print(f"주제 '{topic}' 키워드 없음, 주제명에서 추출: {topic_words}")  # 디버깅
        
        self._visualize_graph(
            G,
            title="주제 관계 그래프 (Topic Relationship Graph)",
            output_path=str(output_path),
            node_size_attr="size",
            topic_keywords=topic_representative_keywords,
            similarity_matrix=similarity_matrix,
            topic_list=topic_list
        )
        
        return str(output_path)
    
    def create_document_graph(
        self,
        documents: List[Dict],
        top_k: int = 3,
        output_path: Optional[str] = None
    ) -> str:
        """
        문서 레벨 관계 그래프를 생성합니다. (PDF 파일 단위)
        
        Args:
            documents: 문서 리스트 (각 문서는 content, source_file, page를 포함)
            top_k: 각 노드당 최대 연결 수
            output_path: 출력 파일 경로
            
        Returns:
            생성된 이미지 파일 경로
        """
        if not documents:
            raise ValueError("문서 리스트가 비어있습니다.")
        
        # PDF 파일별로 그룹화
        file_groups = {}
        for doc in documents:
            source_file = doc.get('source_file', 'Unknown')
            if source_file not in file_groups:
                file_groups[source_file] = []
            file_groups[source_file].append(doc)
        
        if len(file_groups) < 2:
            raise ValueError(f"PDF 파일이 {len(file_groups)}개뿐입니다. 그래프를 생성하려면 최소 2개 이상의 PDF 파일이 필요합니다.")
        
        # 각 PDF 파일의 대표 임베딩 생성 (여러 청크의 평균 또는 첫 번째 청크)
        file_embeddings = {}
        file_info = {}
        
        for source_file, doc_list in file_groups.items():
            # 각 파일의 여러 청크 임베딩 생성
            chunk_embeddings = []
            
            for doc in doc_list[:5]:  # 최대 5개 청크만 사용
                content = doc.get('content', '')
                if not content or len(content.strip()) == 0:
                    continue
                
                # 내용이 너무 짧으면 확장
                if len(content) < 100:
                    content = content * 2
                
                content = content[:1000]  # 처음 1000자만 사용
                
                try:
                    embedding = self.embeddings.embed_query(content)
                    chunk_embeddings.append(embedding)
                except Exception as e:
                    print(f"임베딩 생성 오류 ({source_file}): {str(e)}")
                    continue
            
            if chunk_embeddings:
                # 여러 청크의 평균 임베딩 사용
                avg_embedding = np.mean(chunk_embeddings, axis=0)
                file_embeddings[source_file] = avg_embedding
                
                # 파일 정보 저장
                first_doc = doc_list[0]
                file_info[source_file] = {
                    'file': source_file,
                    'chunk_count': len(doc_list),
                    'first_page': first_doc.get('page', 'N/A')
                }
        
        if len(file_embeddings) < 2:
            raise ValueError(f"임베딩 생성에 성공한 PDF 파일이 {len(file_embeddings)}개뿐입니다. 최소 2개 이상 필요합니다.")
        
        # 유사도 계산
        from sklearn.metrics.pairwise import cosine_similarity
        
        file_list = list(file_embeddings.keys())
        embeddings_matrix = np.array([file_embeddings[f] for f in file_list])
        similarity_matrix = cosine_similarity(embeddings_matrix)
        
        # 그래프 생성
        G = nx.Graph()
        
        # 노드 추가 (PDF 파일 단위)
        for file_name in file_list:
            info = file_info[file_name]
            # 파일명만 표시 (너무 길면 잘림)
            short_name = file_name.replace('.pdf', '')
            if len(short_name) > 30:
                short_name = short_name[:27] + "..."
            
            # 청크 개수 정보 포함
            label = f"{short_name}\n({info['chunk_count']}청크)"
            G.add_node(file_name, label=label, full_name=file_name, chunk_count=info['chunk_count'])
        
        # 엣지 추가 (Top-K 필터링)
        for i, file1 in enumerate(file_list):
            similarities = []
            for j, file2 in enumerate(file_list):
                if i != j:
                    similarities.append((j, similarity_matrix[i][j]))
            
            # 상위 K개만 선택
            similarities.sort(key=lambda x: x[1], reverse=True)
            top_similarities = similarities[:top_k]
            
            for j, sim_score in top_similarities:
                if sim_score > 0.3:  # 파일 간 임계값
                    file2 = file_list[j]
                    G.add_edge(file1, file2, weight=sim_score)
        
        # 연결된 노드가 없는 경우 처리
        if len(G.edges()) == 0:
            # 모든 노드를 연결 (유사도가 낮아도)
            for i, file1 in enumerate(file_list):
                for j, file2 in enumerate(file_list):
                    if i != j:
                        sim_score = similarity_matrix[i][j]
                        if sim_score > 0.1:  # 매우 낮은 임계값
                            G.add_edge(file1, file2, weight=sim_score)
                            break  # 각 노드당 하나만 연결
        
        # 그래프 시각화
        if output_path is None:
            output_path = self.graph_dir / "document_graph.png"
        else:
            output_path = Path(output_path)
        
        self._visualize_graph(
            G,
            title="문서 관계 그래프 (Document Relationship Graph)",
            output_path=str(output_path),
            use_labels=True,
            label_attr="label"
        )
        
        return str(output_path)
    
    def _visualize_graph(
        self,
        G: nx.Graph,
        title: str,
        output_path: str,
        node_size_attr: Optional[str] = None,
        use_labels: bool = False,
        label_attr: Optional[str] = None,
        topic_keywords: Optional[Dict[str, List[str]]] = None,
        similarity_matrix: Optional[np.ndarray] = None,
        topic_list: Optional[List[str]] = None
    ):
        """
        그래프를 시각화하여 이미지로 저장합니다.
        
        Args:
            G: NetworkX 그래프 객체
            title: 그래프 제목
            output_path: 저장할 파일 경로
            node_size_attr: 노드 크기를 결정할 속성명
            use_labels: 노드에 레이블 표시 여부
            label_attr: 레이블로 사용할 속성명
        """
        # 그래프 크기 조정 (여백 줄이기)
        plt.figure(figsize=(14, 10))
        
        # 레이아웃 설정 (노드 간 거리 조정)
        pos = nx.spring_layout(G, k=1.5, iterations=100, seed=42)
        
        # 노드 크기 설정 (더 크게)
        if node_size_attr:
            node_sizes = [G.nodes[node].get(node_size_attr, 100) * 100 + 2000 for node in G.nodes()]
        else:
            node_sizes = [3000] * len(G.nodes())  # 기본 크기 증가
        
        # 엣지 두께 및 스타일 설정 = 유사도 강도에 비례
        # 유사도가 높을수록 굵게, 낮을수록 얇게
        solid_edges = []
        dashed_edges = []
        solid_widths = []
        dashed_widths = []
        solid_alphas = []
        dashed_alphas = []
        
        for u, v in G.edges():
            weight = G[u][v].get('weight', 0.5)
            edge_style = G[u][v].get('style', 'solid')
            edge_alpha = G[u][v].get('alpha', 0.8)
            
            # 유사도(0~1)를 엣지 두께로 변환
            if edge_style == 'solid':
                # 실선: 2~8
                edge_width = max(2, min(8, weight * 8 + 2))
                solid_edges.append((u, v))
                solid_widths.append(edge_width)
                solid_alphas.append(edge_alpha)
            else:
                # 점선: 0.5~2
                edge_width = max(0.5, min(2, weight * 2 + 0.5))
                dashed_edges.append((u, v))
                dashed_widths.append(edge_width)
                dashed_alphas.append(edge_alpha)
        
        # 그래프 그리기
        nx.draw_networkx_nodes(
            G, pos,
            node_size=node_sizes,
            node_color='lightblue',
            alpha=1.0,  # 완전 불투명
            edgecolors='darkblue',  # 더 진한 테두리
            linewidths=3  # 더 두꺼운 테두리
        )
        
        # 굵은 실선 엣지 (높은 유사도)
        if solid_edges:
            nx.draw_networkx_edges(
                G, pos,
                edgelist=solid_edges,
                width=solid_widths,
                alpha=solid_alphas,
                edge_color='darkgray',
                style='solid'
            )
        
        # 얇은 점선 엣지 (낮은 유사도)
        if dashed_edges:
            nx.draw_networkx_edges(
                G, pos,
                edgelist=dashed_edges,
                width=dashed_widths,
                alpha=dashed_alphas,
                edge_color='lightgray',
                style='dashed'
            )
        
        # 레이블 표시
        if use_labels and label_attr:
            labels = {node: G.nodes[node].get(label_attr, str(node)) for node in G.nodes()}
            nx.draw_networkx_labels(
                G, pos,
                labels=labels,
                font_size=10,  # 폰트 크기 증가
                font_family='Malgun Gothic',
                font_weight='bold',
                bbox=dict(boxstyle='round,pad=0.5', facecolor='white', alpha=0.9, edgecolor='darkblue', linewidth=2)
            )
        else:
            # 주제명 표시 (더 크고 선명하게)
            labels = {node: node[:20] + "..." if len(node) > 20 else node for node in G.nodes()}
            nx.draw_networkx_labels(
                G, pos,
                labels=labels,
                font_size=14,  # 폰트 크기 증가 (12 -> 14)
                font_family='Malgun Gothic',
                font_weight='bold',
                bbox=dict(boxstyle='round,pad=0.6', facecolor='white', alpha=0.9, edgecolor='darkblue', linewidth=2)
            )
        
        # 주제 노드 아래에 대표 키워드 표시
        if topic_keywords:
            ax = plt.gca()
            # 노드 크기 매핑 생성 (G.nodes() 순서 기준)
            node_size_map = {}
            nodes_list = list(G.nodes())
            if node_size_attr:
                for i, node in enumerate(nodes_list):
                    if i < len(node_sizes):
                        node_size_map[node] = node_sizes[i]
                    else:
                        node_size_map[node] = 3000
            else:
                for node in nodes_list:
                    node_size_map[node] = 3000
            
            print(f"키워드 표시 시작: topic_keywords keys = {list(topic_keywords.keys())}")  # 디버깅
            print(f"노드 리스트: {nodes_list}")  # 디버깅
            
            for node in nodes_list:
                keywords = topic_keywords.get(node, [])
                print(f"노드 '{node}' 키워드: {keywords} (타입: {type(keywords)}, 길이: {len(keywords) if keywords else 0})")  # 디버깅
                
                if keywords and len(keywords) > 0:
                    # 빈 문자열 제거
                    keywords = [kw for kw in keywords if kw and kw.strip()]
                    
                    if len(keywords) > 0:
                        x, y = pos[node]
                        # 노드 아래에 키워드 표시 (노드 중심에서 아래로)
                        # 노드 크기에 따라 키워드 위치 조정
                        node_size = node_size_map.get(node, 3000)
                        # 노드 반지름 계산: NetworkX의 node_size는 상대적 크기
                        # matplotlib 좌표계에서 실제 표시 크기는 더 작음
                        # offset_y를 조정하여 키워드를 노드 아래 적절한 거리에 표시
                        # 노드에 붙지 않도록 적절한 간격 유지
                        offset_y = -0.07  # 노드 바로 아래에 표시 (조금 더 내려서 간격 확보)
                        
                        # 키워드를 "· 키워드1 · 키워드2 · 키워드3" 형식으로 표시
                        keyword_text = " · ".join(keywords[:3])  # 최대 3개
                        if len(keyword_text) > 50:  # 너무 길면 자름
                            keyword_text = keyword_text[:47] + "..."
                        
                        print(f"키워드 텍스트 표시: '{node}' -> '{keyword_text}' at ({x:.2f}, {y + offset_y:.2f})")  # 디버깅
                        
                        # 키워드 텍스트 표시
                        ax.text(
                            x, y + offset_y,
                            keyword_text,
                            fontsize=11,
                            fontfamily='Malgun Gothic',
                            ha='center',
                            va='top',
                            bbox=dict(
                                boxstyle='round,pad=0.5',
                                facecolor='lightyellow',
                                alpha=0.95,
                                edgecolor='orange',
                                linewidth=2
                            ),
                            zorder=100  # 다른 요소 위에 표시 (zorder 증가)
                        )
                    else:
                        print(f"노드 '{node}': 키워드가 모두 빈 문자열입니다.")  # 디버깅
                else:
                    print(f"노드 '{node}': 키워드가 없습니다.")  # 디버깅
        
        plt.title(title, fontsize=18, fontweight='bold', pad=10)  # 여백 줄임
        plt.axis('off')
        plt.tight_layout(pad=0.5)  # 여백 최소화
        plt.savefig(output_path, dpi=200, bbox_inches='tight', facecolor='white', pad_inches=0.1)  # DPI 증가, 여백 최소화
        plt.close()
    
    def get_topic_documents(
        self,
        topic: str,
        topic_docs: Dict[str, List[str]],
        vector_store_manager
    ) -> List[Dict]:
        """
        특정 주제에 속한 문서들의 상세 정보를 가져옵니다.
        
        Args:
            topic: 주제명
            topic_docs: 주제별 문서 딕셔너리
            vector_store_manager: 벡터스토어 관리자
            
        Returns:
            문서 정보 리스트
        """
        doc_files = topic_docs.get(topic, [])
        if not doc_files:
            return []
        
        # 벡터스토어에서 해당 문서들 검색
        # 각 파일에서 여러 청크를 가져와서 그래프 생성
        documents = []
        file_chunk_count = {}  # 파일별 청크 개수 추적
        
        try:
            # 벡터스토어에서 모든 문서 가져오기 (더 많은 결과)
            # 간단한 쿼리로 많은 문서를 가져온 후 필터링
            results = vector_store_manager.search(query=" ", k=1000)  # 더 많은 결과 가져오기
            
            # 해당 파일의 문서만 필터링 (각 파일당 최대 5개 청크)
            for doc in results:
                source_file = doc.metadata.get("source_file", "")
                if source_file in doc_files:
                    # 각 파일당 최대 5개 청크만 사용
                    if file_chunk_count.get(source_file, 0) < 5:
                        documents.append({
                            'content': doc.page_content,
                            'source_file': source_file,
                            'page': doc.metadata.get("page", "N/A")
                        })
                        file_chunk_count[source_file] = file_chunk_count.get(source_file, 0) + 1
                    
                    # 모든 파일에서 충분한 청크를 수집했는지 확인
                    if all(file_chunk_count.get(f, 0) >= 3 for f in doc_files):
                        break
                        
        except Exception as e:
            print(f"문서 검색 오류: {str(e)}")
            # 대안: 각 파일별로 개별 검색
            for doc_file in doc_files:
                if file_chunk_count.get(doc_file, 0) >= 5:
                    continue
                try:
                    # 파일명의 일부를 쿼리로 사용
                    query_text = doc_file.replace('.pdf', '').replace('_', ' ').replace('-', ' ')[:30]
                    results = vector_store_manager.search(query=query_text, k=50)
                    
                    for doc in results:
                        if doc.metadata.get("source_file") == doc_file:
                            if file_chunk_count.get(doc_file, 0) < 5:
                                documents.append({
                                    'content': doc.page_content,
                                    'source_file': doc_file,
                                    'page': doc.metadata.get("page", "N/A")
                                })
                                file_chunk_count[doc_file] = file_chunk_count.get(doc_file, 0) + 1
                            
                            if file_chunk_count.get(doc_file, 0) >= 5:
                                break
                except Exception as e2:
                    print(f"문서 검색 오류 ({doc_file}): {str(e2)}")
                    continue
        
        # 최소 2개 이상의 문서 청크가 있는지 확인
        if len(documents) < 2:
            print(f"경고: 수집된 문서 청크가 {len(documents)}개뿐입니다. (파일: {len(doc_files)}개)")
            print(f"파일별 청크 수: {file_chunk_count}")
        
        return documents


if __name__ == "__main__":
    # 테스트 코드
    kg = KnowledgeGraph()
    print("KnowledgeGraph 초기화 완료")

